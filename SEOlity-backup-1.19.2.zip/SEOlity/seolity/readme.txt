=== ARIAGH.SEOLITY – AI SEO Intelligence for WordPress ===
Contributors: seolity
Tags: seo, ai, search console, woocommerce, schema
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.19.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

An AI-powered SEO operating system: site audits, Google Search Console analytics, AI content and product optimization with preview/approval/undo, experiments, redirects, schema and more. Persian (RTL) and English.

== Description ==

SEOlity measures, decides, acts safely and learns:

* **Measure** – a real crawler with ~60 checks, Google Search Console analytics (page × query × day), content analysis, competitor monitoring, PageSpeed data.
* **Decide** – SEO Doctor diagnoses, a prioritized AI Action Center ("What should I do today?") with impact, effort, confidence and a "Why?" explanation for everything, rules engine, daily AI briefing, AI SEO chat grounded in your data.
* **Act safely** – "✨ Optimize with SEOlity AI" in Gutenberg, the Classic editor, Elementor, terms, author profiles and WooCommerce products. Every change is previewed (original / suggested / diff), approved (Manual, Semi-automatic or Autonomous mode), versioned and reversible. High-risk changes always need a human.
* **Learn** – applied changes become measured experiments; results feed back into future AI suggestions. A curated SEO knowledge base (Persian + English) grounds every AI answer and can be kept fresh from GitHub.

White-hat only: guardrails reject keyword stuffing, hidden text, removed links and invented facts.

Works alongside Yoast SEO, Rank Math, SEOPress and AIOSEO (reads/writes their fields) or standalone. WooCommerce HPOS compatible.

Full documentation: `docs/ARCHITECTURE.md` and the 579-feature catalog in `docs/FEATURES.md`.

== Installation ==

1. Upload the `seolity` folder to `/wp-content/plugins/` (or upload the ZIP in Plugins → Add New) and activate it.
2. **AI** – SEOlity → Settings → AI: choose a provider (Anthropic Claude, OpenAI, Google Gemini, OpenRouter, a local Ollama server or any OpenAI-compatible API) and enter its key. Click "Test connection".
   **Or use your subscription** (Claude Pro/Max or ChatGPT Plus/Pro) instead of an API key: SEOlity → Settings → Subscription AI. Save a GitHub token (Contents, Actions, Secrets, Workflows), enter a repository name, paste the output of `claude setup-token` (or the contents of `~/.codex/auth.json` after `codex login`) and click "Set up GitHub runner". Answers take about 1–3 minutes; SEOlity waits automatically.
3. **Search Console** – create an OAuth client (type "Web application") in Google Cloud Console, enable the "Google Search Console API", add the redirect URI shown in SEOlity → Settings → Search Console, then paste the Client ID and Secret and click Connect. Choose your property.
4. **First audit** – SEOlity → Site Audit → Start audit. Work continues in the background.
5. Optional: SerpApi key (live SERP analysis), PageSpeed Insights key, a GitHub fine-grained token (knowledge sync / data storage), competitors.

For large sites, disable WP-Cron and run the queue from a real cron job:

`* * * * * wp seolity queue run --seconds=50 --path=/var/www/html`

Secrets can be defined in wp-config.php instead of the database, e.g. `define( 'SEOLITY_ANTHROPIC_API_KEY', '…' );` and `define( 'SEOLITY_ENCRYPTION_KEY', '…' );`.

== External services ==

SEOlity only contacts external services that you configure:

* **AI providers** (Anthropic, OpenAI, Google Gemini, OpenRouter, your own endpoint) – page content and SEO data needed for the requested task are sent when you (or a rule you created) run an AI action. Each provider's terms and privacy policy apply.
* **GitHub Actions + Claude Code / OpenAI Codex** (subscription AI, optional) – AI requests are written encrypted to your private GitHub repository and processed there by the official CLI with your own Claude or ChatGPT plan; results are posted back to your site (HMAC-signed) or collected from GitHub.
* **Cloudflare API + your Cloudflare Worker** (optional) – when you connect Cloudflare, SEOlity uses the Cloudflare API with your token to deploy a worker on your account; encrypted subscription results pass through its KV mailbox and its cron calls your site's REST API to run the background queue. Cloudflare terms: https://www.cloudflare.com/terms/ · Privacy: https://www.cloudflare.com/privacypolicy/
* **Custom API** (optional) – prompts are sent to the AI service whose address you enter, under that service's terms.
* **Google Search Console API / OAuth** – read-only Search Console data for the property you select (https://policies.google.com/privacy).
* **Google PageSpeed Insights API** – the URL you test.
* **SerpApi** – the keyword and market you analyze (https://serpapi.com/legal).
* **GitHub API** – knowledge base sync (public repository by default) and, if enabled, archiving of your SEO data to the private repository you choose (https://docs.github.com/site-policy).
* **Google Fonts** (admin only, optional) – the Vazirmatn typeface for the admin screens; turn it off in Settings → General (https://policies.google.com/privacy).
* **Competitor websites** – their public sitemaps and pages, fetched politely (robots.txt respected).

No data is sent to the plugin authors.

== Frequently Asked Questions ==

= Will SEOlity change my content without asking? =
No. In Manual mode nothing is applied without approval. Semi-automatic applies only low-risk changes (e.g. ALT text, meta descriptions); Autonomous adds medium-risk ones. Content, titles, slugs, canonical and noindex always require approval, and every change can be reverted.

= Do I need another SEO plugin? =
No. SEOlity outputs titles, meta, Open Graph, canonical, robots and JSON-LD when it is the SEO engine, and steps back automatically when Yoast, Rank Math, SEOPress or AIOSEO is active.

= Is it suitable for Persian sites? =
Yes. The interface is fully translated and RTL-native, text analysis understands Persian (ZWNJ, Arabic ي/ك, Persian digits), Persian URLs are handled correctly, and the knowledge base includes Iran-specific guidance (e.g. IRR currency in product schema).

= How do I remove all data? =
Enable "Delete all data on uninstall" in Settings → Privacy, then delete the plugin.

== Changelog ==

= 1.19.2 =
* Fix: the "your browser" bookmark said "no results found" on current Google result pages. Version 2 of the bookmark reads result titles in the classic and the newer layouts and falls back to the result links; ads, Google's own links and the page header are skipped; a CAPTCHA page or a page without a search gets a clear message. Delete the old bookmark and drag the new one (v2) again.

= 1.19.1 =
* Fix: Google results sent with the free "your browser" bookmark were saved for the competitor pages only; "Road to #1" and its AI plan now read them too (the newest of the results API cache and the stored results). The bookmark button is also on the "Road to #1" page, and an import of the focused search returns there. Live checks are kept in the results history.

= 1.19.0 =
* Road to #1 (new page): every search the site appears for, with its real Google position (Search Console), an honest chance of #1 (already #1 / very close / realistic / hard / long shot — from the numbers, not hope) and what #1 would bring (marked as an estimate). Focus on ONE search: the AI compares the page with the result that ranks first and gives an honest verdict, a realistic time frame, the gaps, the few steps that move this search (each prepared for review with one click) and what is not worth the time. Progress and wins are shown only from Search Console data after the focus started. Live check: the configured Google results source, or "Open in Google" for a private window (scraping Google from the server is deliberately not done).
* 404 monitor: new URLs are sorted by real evidence (Search Console history, real links, real referrers, Googlebot, deleted posts). Security-scanner probes without any value (phpinfo, _profiler, .env, …) are moved to "Hidden: not important"; URLs with value are marked with the reason; the AI review also hides the ones it judges worthless. Nothing on the site changes; any URL can be brought back.
* 404 monitor: select URLs (also "the ones without a suggestion") and hide / bring back, let the AI decide for exactly those, or send them as a package to the AI chat and talk about them — the chat can prepare the decisions for exactly those URLs.
* Redirect chains as a picture: today (A → B → C) and after the fix (A → C, B → C), loops marked. Fix by pointing every step to the final page, or let the AI choose the best final page from checked live pages (topic match first, then the page that matters more, e.g. the shop or a category). Reviewed, verified and undoable like every operation.
* Fix: chains that run through Rank Math redirects were not detected (only SEOlity's own rules were), and "Flatten chains" changed only SEOlity's copy, not the rule in Rank Math.

= 1.18.0 =
* "Optimize with SEOlity AI" now optimizes the whole page in one go: the content from top to bottom (or writes it when it is empty, e.g. a new category), the SEO title, the meta description and the focus keyword for Rank Math / Yoast / SEOPress / AIOSEO, plus — opt-in — a better page title (H1). Rank Math's secondary keywords are kept.
* Default instruction + your own: every run uses a default instruction (built-in, or your own in Settings → AI → "Default instruction for Optimize with SEOlity AI"); the window has a box for an extra instruction for this page, which wins over the default.
* Fix: on category, tag and product-category screens "Apply to editor" changed nothing — it looked for the post editor. The result now goes into the category description (plain field or Rank Math's rich editor, every copy), and the SEO plugin's own fields on the screen are filled too, so its "Update" does not write the old title, description or keyword back.
* Fix: a category's text was sent as "post_content", so no reviewable change was recorded for it; it is now the category description.

= 1.17.1 =
* Fix: after "log out of all devices" in Claude (every token revoked) a new token saved in SEOlity did not reach every place the old one was kept, so runs kept failing with "OAuth token revoked". Saving a login now replaces the copy in the runner repository AND in the site's own knowledge repository, and stops runner runs that started with the old login (a GitHub run keeps the secrets it started with).
* Fix: "Collect knowledge" always writes the saved login to the knowledge repository again; before, an existing (possibly revoked) copy was never replaced.
* The save message says which GitHub repositories were updated and whether the runner was restarted. New troubleshooting entry in the guide.

= 1.17.0 =
* Road to position 1: the SEO roadmap is ONE path (treasure-map style) instead of two separate parts — start (data & analysis), one station per area in the order it must be done (the open issues and the AI's strategy tasks of that area together), the goal (position 1 on Google). Done stations glow, the current one pulses with a "you are here" pin, the road draws itself; click a station to open its tasks. A mission card shows the progress, the wins so far and the AI guide's diagnosis. The AI now picks the target searches to win, who ranks first and the gap to close.
* The site's SEO brain (Experiments): learning no longer waits for single experiments to be significant (on a small site most are inconclusive) — effects are pooled by change type. New panel with measured observations from the site's own data (growth, the site's CTR per position vs typical, question / buying / brand searches, searches already at position 1, the shortest road to position 1, what the best pages have in common, devices, best weekday, measured impact of changes) and what the AI concluded: beliefs with evidence and confidence, wins, open questions, experiments worth running and the strategy to position 1. Re-thought weekly and on demand; used in every AI prompt.
* Fix: "Evaluate now" and "Analyze the edit history" run right away and the page refreshes itself with the results.
* AI tone setting (Settings → AI): warm and teaching (explains everything from zero), friendly, professional or expert. Every AI text follows a strict-but-positive mindset aimed at position 1 — problems in detail, and always what is already going well.
* Knowledge builder (GitHub): a Claude / ChatGPT subscription token is now used before an Anthropic API key (an old key without credit made every run fail), a billing error stops the run at once, and the builder files in the repository are updated before every run.

= 1.16.0 =
* New page: Index coverage (Technical SEO). Upload the Search Console "Pages" exports (the summary and each reason as ZIP — Google has no API for this report) and SEOlity separates intentional exclusions (feeds, cart, add-to-cart, tracking parameters, theme internals) from real problems: published articles whose own address redirects, redirect chains, rules that point at the wrong article, live-traced redirect errors (loop, long chain, broken end), 404s with a likely destination, deleted files still linked, truncated Persian links (�), noindex on landing pages, real pages in "Crawled – currently not indexed", and jumps in the indexed timeline matched with the changes made those days. Every fix is an operation you approve (and can undo).
* Search Console messages: paste the e-mail (e.g. "New reasons prevent pages in a sitemap from being indexed") — SEOlity recognises the type and reasons, explains it, notifies you (also by e-mail) and the AI connects it with your data and puts a plan on the SEO roadmap.
* Daily index watch: Google URL Inspection for a rotating batch of your pages, sitemap errors and redirect hygiene — a notification when a NEW reason appears, usually before Search Console's own e-mail.
* Change impact 2.0 (follow-ups): every applied change is measured on day 7, 14, 28 and long-term, comparing equal windows before/after the change and correcting by the whole site's trend; merged or moved pages are measured as one group plus the queries they ranked for; verdict positive / negative / neutral / too little data with a confidence level. Clear early results warn you (undo possible), the main result is always reported, the AI explains it and adds next steps to the roadmap, and every result builds the site's record of "what worked here", which the AI uses when it plans.
* Fix: positive results ("Good news") were never e-mailed by default.
* Consolidation now also unpublishes the merged article (as a draft, after its redirect works), so it leaves the sitemap; undo publishes it again. Correcting a redirect target through an operation keeps the old rule for undo.
* SEO knowledge: choose the search market (Iran / international / automatic). 14 new in-depth documents — 9 for the Iranian market (market overview, hosting/CDN and Googlebot access, Persian language and URL rules, Torob / Digikala / Basalam / eNamad and Product schema in IRR, reportage links, content, seasonality calendar, keyword research without sanctioned tools, local SEO with Neshan / Balad) and guides to the Page indexing report, Search Console messages, change measurement, URL migrations and YMYL health content. Persian knowledge grew from about 1,700 to 16,500 words; it is loaded automatically after every update.

= 1.15.0 =
* Simpler navigation, like the ARIAGH AI Writer admin: every page is its own item in the WordPress menu and in the SEOlity sidebar, listed under small group headings (Overview, Data collection, Content, Keywords & links, Technical SEO, Connections, Settings). No more section tabs on top of page tabs: one click opens one page.
* The AI chat and the SEO roadmap are the two large tiles at the top of the sidebar; the chat tile shows the connected AI engine and model. Search Console and GitHub status moved to the top bar.
* Settings are split into separate pages (General, AI, Crawler & audits, Alerts & reports, Technical, Schema & entity, Privacy & data). Old links such as #/settings?tab=ai still open the right page.

= 1.14.0 =
* The AI chat can act, not only advise. From an answer it can add SEO roadmap items (any category, now also "Backlinks & off-site" for reportage and link campaigns, with the priority you ask for), prepare changes to the site that wait in the floating popup for "Review & apply" (nothing is applied without your approval), schedule follow-ups and send you notifications. What it created is shown under the answer with links.
* Follow-ups: SEOlity records the Search Console numbers of the pages and queries when a follow-up is created and measures them again on the check date (e.g. a month after a reportage), then reports better / worse / no change with the numbers. Every applied change gets a follow-up automatically after 28 days.
* Notifications center: warnings, results, good news, AI messages and info in separate tabs with big cards, follow-ups, and e-mail settings — several recipients, instant or a daily digest, which kinds to send, a test e-mail, and the exact reason when sending fails (e.g. the SMTP error).
* Page importance: before suggesting a redirect, title, description or content change, SEOlity checks whether the page matters — post type (Elementor templates, floating buttons, blocks), whether a template is used anywhere, status, noindex, menus, internal links, sitemap, Google clicks and sales. Unused templates and building blocks get no SEO suggestions; drafts and noindex pages are demoted. The chat sees the same information.

= 1.13.4 =
* Fix: the AI chat now gets the real Search Console rows per page and per query. With a subscription or the GitHub route the chat does not run the extra AI tool planner, and questions about reportage, backlinks, anchors or "you are connected to Search Console" matched no data tool, so only the site totals reached the AI. New data tool "gsc_opportunities": every page in positions 4–20 with its clicks, impressions, position and the queries it ranks for, plus the strongest commercial pages; wider keyword routing in Persian and English. No extra Search Console permission is needed — the read-only access already syncs page × query rows.
* Fix: with the route set to Direct, the header and the chat said "github" for Claude/ChatGPT subscriptions although requests ran on this server's CLI. The route shown is now where requests really go (Direct = the CLI installed here; GitHub = the runner).

= 1.13.3 =
* The AI runner repository on GitHub is now PUBLIC, and the knowledge base and data archive go to a separate PRIVATE repository. Why: GitHub Actions minutes are free for public repositories, while a private repository uses the account's paid quota — and when a payment fails or the spending limit is reached, GitHub does not start the jobs at all ("The job was not started because recent account payments have failed…"), so no AI answer ever came back. The public runner only holds its code and AES-256-GCM encrypted requests and answers; subscription logins and keys stay in GitHub Secrets, which are hidden in public repositories, and run logs print no site content.
* New installs: one click creates `<you>/seolity-ai-runner` (public) and `<you>/seolity-ai` (private, knowledge + data). Existing private runners are made public on the next "Install / update runner" — but only when they hold no knowledge or data: a repository with the seolity-data branch, the knowledge folder, or one that cannot be checked, always stays private. Knowledge and data are refused in a public repository.
* Status and guides explain the choice; a private runner shows a warning instead of an error.

= 1.13.2 =
* Fix: AI answers, GitHub results and competitor analyses no longer wait until they expire after a CLI was installed. "Auto" now answers with this server's Claude Code / Codex only after "Test connection" has passed here with the current login; until then every request goes to the GitHub runner as before. If a tested local CLI later fails for a server reason (memory limit, blocked network, timeout), that request and the next ones go to GitHub automatically; a login problem is shown instead.
* Fix: Codex runs no longer wait on each other without limit (a blocked lock is not counted by PHP's time limit and could freeze every background worker); a busy CLI now answers "busy" after 20 s. The Codex sign-in no longer holds that lock while waiting for you.
* Fix: when Codex refreshes its login on this server, the copy used by the GitHub runner is updated too (OpenAI revokes the previous refresh token).
* The engine cards show where requests are answered (this server or GitHub runner); installs report progress to the queue so they are not mistaken for dead workers.

= 1.13.1 =
* Fix: Codex install on LiteSpeed/CloudLinux hosting no longer ends in a memory limit. Every program PHP starts inherits PHP's per-process virtual-memory limit, and `npm install` needs well over 1 GB for the 430 MB Codex package. Codex is now installed without npm: the official build is streamed from the npm registry straight to disk, checked against the registry's sha512 signature, unpacked and tested (tested at a 1 GB limit: 7 s, 71 MB PHP memory). The native program needs no Node.js. Existing npm installs are used through their native program too.
* Fix: the AI Engines page no longer reloads itself every few seconds during an install. It polls a light status (no program is started) and shows a progress bar; a failed `--version` check is remembered for 10 minutes; an install killed by the host is reported instead of "running" forever.
* Soft memory limits are raised to the host's hard limit for every run; diagnostics show the virtual-memory limit and what Codex (about 1 GB) and npm (about 2 GB) need.
* Choose the model right on the AI Engines page (Codex models come from the installed program, offline). The CLI section left Server & speed.
* Large horizontal cards: duplicate articles, competitor queries and AI-search visibility.

= 1.13.0 =
* AI engines — Installation & Diagnostics (Connections): one page to check the server, install or repair Claude Code / Codex, sign in, test and copy a support report; clear status per engine (ready, needs configuration, authentication required, not installed, permission denied, unsupported environment, runtime error) with the cause and the next step.
* Node.js is found automatically wherever the host put it (CloudLinux /opt/alt/alt-nodejs*, cPanel ea-nodejs, ~/nodevenv, nvm, Volta …), validated and passed to every CLI run, so `#!/usr/bin/env node` works even when PHP has a short PATH.
* One process runner for every program: argument lists only, explicit environment, timeouts, exit codes, no shell.
* Errors are recognised: a revoked or expired login is reported as such (never as a memory problem) and stops further runs until you reconnect; memory, timeout, network, rate-limit and permission errors each get their own message.
* Codex sign-in from WordPress with the official device code; logins stay in a private folder (0700/0600) outside the web root, refreshed tokens are kept, an older login never overwrites a newer one.
* Claude and Codex are fully independent: one failing never blocks the other.

= 1.12.1 =
* Site map: every URL is now a large horizontal card (status icon and colour, title, address, what Google does with it, clicks, impressions, position, internal links, depth, words, warnings, Details / Open page); status tiles and folders use the dashboard card style; whole-site bar; the square picture moved to its own tab.
* Competitors: "who you meet most in Google" is shown as cards with a presence bar instead of a small table.

= 1.12.0 =
* Google results from your choice of source, with what each costs and needs: Serper.dev (2,500 free searches, email only), SearchApi.io, SerpApi, DataForSEO, Google Programmable Search (official) — or "your own browser": no key, account, phone or card; search in an incognito window and one bookmark click sends the results page to SEOlity.
* Visibility in AI search: SEOlity asks Gemini (with Google Search — free tier), Claude with web search, ChatGPT web search or Perplexity your tracked queries and records whether your site is cited, in which place and which competitors are cited instead; checked weekly.
* The AI chat can see everything: a snapshot of the whole site and plugin, every setting (never secrets) and connection, and 19 data tools (Search Console per query/page, page audit, roadmap, issues, audit, indexability, duplicates, 404s, competitors, Google and AI results, experiments, site map, activity) chosen by a short planning step for each question; answers link straight to the right page and tab and never claim to have no access.
* "Where the site's problems are": a weighted breakdown by area — technical & indexing, on-page, internal links, content & cannibalization, speed, products, off-site — with the share, affected URLs and top problems; the AI diagnosis ranks the areas.
* Much stronger cannibalization detection: topic similarity (TF-IDF), the queries two pages split in Search Console and how often Google swapped them week by week, search intent, a severity score, and the right strategy with alternatives — merge, differentiate (AI retargets one article to its own query), canonical, or strengthen with internal links — each previewed and verified.
* New site map explorer: every URL of the site (crawl, XML sitemap, WordPress, Search Console) coloured by what Google can do with it — indexable, noindex, blocked by robots.txt, redirect, error, canonicalized, not crawled — with flags (orphan, not in sitemap, sitemap problem, deep, thin, slow, traffic, Google-only), a pixel map of the whole site, folder tree, sortable list with CSV export, daily trend and a detail panel per URL (live re-check, Search Console inspection, rich results and PageSpeed links). Rebuilt every day.
* Phones: the end of every page stays reachable above the task dock.

= 1.11.0 =
* The AI now sees every detail of Search Console: for any query or page named in a question (or matched from your stored queries) it gets the weekly clicks, impressions and position for the whole stored period, which of your pages Google showed in which week (page swaps — e.g. "why does the category page rank instead of the home page"), the sharpest drop with the edits made around it, the measured results of past edits and the home page's own numbers. Answers like "only site totals are available" no longer happen when the data exists.
* Edit history: edits made in WordPress or a page builder are measured like SEOlity's own changes, and "Analyze the edit history" measures past edits from WordPress revisions inside your Search Console period — each with a before/after verdict (positive, negative, neutral) and the position change of every main query.
* New competitor workspace: SEOlity searches your tracked queries in Google through the SERP API (location-specific, not personalized — the incognito view; scraping Google directly is against its terms and blocked) and stores every result page as history. Each competitor has its own panel: every query where it is above or below you with its page and trend, its estimated Search Console (queries, pages, clicks — clearly marked as an estimate and how it is calculated), its crawled pages, AI discovery of the queries its pages target, and a tab per analyzed query in which the AI compares their page with yours from the live results, both pages, People Also Ask and your Search Console history, explains why they rank where they do (measured vs. hypothesis), why Google shows the page of yours it shows, and gives ordered steps — which also go to the SEO roadmap. Domains you meet most in Google are suggested as competitors. A monthly search budget prevents surprise costs.
* AI power level per connection (Settings → AI → each provider → "3. AI power"): sent in each provider's real parameter — Anthropic effort, OpenAI reasoning_effort (reasoning models), OpenRouter reasoning.effort, Gemini thinking budget / level, Ollama think, Claude Code MAX_THINKING_TOKENS and Codex model_reasoning_effort; a model that rejects it is asked again without it.
* Models are chosen in one place only: Settings → AI (the subscription wizard and the custom API form no longer have their own model fields); the list always comes from the provider.

= 1.10.0 =
* New: AI review of 404 errors (404 Monitor → "AI review: 301, 410 or leave?"). For every open 404 SEOlity collects the evidence — Search Console clicks/impressions/position of that exact URL, internal links still pointing to it, external referrers, human vs. Googlebot requests, deleted posts at that address and how close each candidate page is — and the AI decides per URL: 301 to a genuine equivalent (to keep its rankings and move crawling to the new URL), 410 when it is gone for good, leave it as 404 when it has no value, or fix a mistyped internal link. It also says honestly whether the 404s cost crawl budget on a site of your size. The AI may only pick targets SEOlity checked; nothing changes until you approve; every 301 and 410 is verified on the live site and the whole review can be undone.
* Undo of a redirect or 410 puts the URL back into the open 404 list.
* The operation window shows a progress message while the AI is still working instead of "Nothing to change was found".

= 1.9.2 =
* Fixed: the indexability audit failed with “Object of class WP_Error could not be converted to string” on sites with a public taxonomy that has no front-end address (common with WooCommerce attributes and filter plugins). Such taxonomies are now skipped instead of stopping the audit.

= 1.9.1 =
* Redirect check: when the old URL still answers 404, SEOlity now clears it in the page cache (LiteSpeed, WP Rocket, W3 Total Cache, WP Super Cache, SiteGround), checks again past the cache, and otherwise says exactly why: Rank Math has no matching redirect, redirects are switched off, a cache answered (HIT), or a CDN / security plugin / server rule answers first. A 404 leaves the open list only after the redirect really answers.
* Before approval, a redirect is flagged when nothing would serve it (SEOlity redirects off and Rank Math Redirections not active).
* Duplicate & near-duplicate articles checks blog articles only (no pages, products or templates) and suggests how to fix the cannibalization; nothing changes until you approve.

= 1.9.0 =
* AI settings rebuilt into two boxes — "AI with API" and "Subscription" — with one panel per provider: key field and link, "Connect & load models" (the models are read from your own account: Anthropic, OpenAI, Gemini, OpenRouter, Ollama, custom APIs and the new GitHub Models), a real one-request model test, a clear status (not connected / key works / model tested) and plain-language errors (wrong key, no credit, model not available, rate limit, network). Fixed: a saved and working AI connection could still show "not configured".
* Subscriptions are offered only the way each company allows: Claude Pro/Max through the official Claude Code program, ChatGPT plans through the official Codex program — on your private GitHub runner or, new, on your own server. SEOlity never asks for passwords or cookies.
* Server & speed → "Check this server & install": checks PHP, Node.js, npm, disk (measured package sizes: Claude Code ≈ 292 MB, Codex ≈ 444 MB), memory and folder rights, and installs the official CLI with one fixed npm command when the host allows it; shared hosts get an honest explanation.
* Tasks: no task stays "running" forever any more. Every background task has a heartbeat and a time limit, is detected when the server kills it, retried and finally marked "timed out". New Task queue tab with cancel, retry, delete and exact counts.
* SEO roadmap («مسیر راه»): one "Run full-site analysis" button updates every section (crawl, Search Console, issues, indexability, duplicates, 404 targets, AI plan). Every problem appears once, with category links in the recommended order and the reason, status, priority, AI recommendation, "Do it with AI" (preview → approval → apply → verify → undo) or manual edit. A checkmark appears only after the result was verified on the live site; "mark as done" by hand is shown as such.
* New: Indexability & crawl budget audit — Elementor templates, attachments, author/date archives, internal search, tags, empty taxonomies, parameter URLs, feeds and pagination are checked live (status, robots meta, X-Robots-Tag, canonical, robots.txt, sitemap, internal links, Rank Math settings, optional Search Console inspection), with the right fix for each (noindex vs robots.txt vs sitemap vs 301) applied in Rank Math and verified.
* New: Duplicate & near-duplicate articles («مقالات تکراری و شبه تکراری») — finds articles that repeat or compete (content overlap, titles, H1, shared queries) and merges them into the strongest one: your standing and per-merge instructions, AI merge, full before/after preview, then noindex, 301 redirects and internal-link updates only after the merged article was saved and verified. Nothing is deleted; every edit keeps a WordPress revision and can be undone.
* 404 monitor: select many URLs and redirect each one to its own target in one step, with validation and a verified result per URL.
* Rank Math is the authority when it is active: robots, titles, descriptions and settings are written where Rank Math reads them, redirects are created in Rank Math Redirections, and every change is checked both in the database and on the live page.
* Navigation: every menu item shows its sections underneath; the knowledge base moved to "Data collection".

= 1.8.0 =
* "Do it" on the dashboard and in the SEO roadmap opens a popup with two sides: exactly where to do it yourself (menu paths and buttons), and the AI's plan for your site. Press "Approve & let the AI do it" and watch every step live (e.g. "Finding pages that should link to …", "Adding the link in …"). It optimizes titles and content, writes FAQs, creates redirects, fixes redirect chains and adds internal links to weak pages by reading related posts across the whole site and writing a natural sentence with the link. Every change is versioned.
* New Activity page (AI Center → Activity) with two tabs: Live activity (what is running now, step by step, with the route each AI request took) and Completed work (an exact timeline of everything SEOlity did on your site: AI answers with route, model, tokens and error details, edits, redirects, audits, Search Console syncs, archives …, filterable and grouped by day).
* AI edit cards (optimizer, titles, products, agent) now run on the server and follow you across every admin page and after a reload until you review and close them; finished cards stay compact.
* Chat: conversations sidebar with search and delete, questions about a specific page, answers that arrive even after a reload or when the page was closed, retry / answer again, copy, and the route, model and time of each answer.
* Direct really means direct: with the Direct route nothing is sent through GitHub. API keys are called directly; a Claude/ChatGPT subscription runs with the official CLI on your own server (VPS), which SEOlity detects and can test under Server & speed. Without the CLI, Direct shows a clear error instead of silently using GitHub.
* Server & speed: choosing a route is instant and no longer reloads the page; a route that is not set up yet explains what to do instead of jumping to another page.

= 1.7.0 =
* New SEO roadmap replaces "What should I do today?": nothing is analyzed until you press "Analyze". SEOlity then reads Search Console, the site audit, your content, new posts and competitors, studies the SEO knowledge base (up to 10 documents plus your site playbook) and writes an expert diagnosis, strengths, risks, the focus for this week and a prioritized plan in four phases (this week, next 2 weeks, this month, later).
* Down to the smallest detail: e.g. new articles Google has not indexed yet (with "Inspect in Search Console" per page, sitemap / internal-link / noindex problems), CTR fixes, page-2 pages, declining pages, cannibalization, broken URLs, thin content, products, images, schema and the AI's own strategic tasks.
* Every task opens a guide: why it matters (with the numbers), the affected pages with Edit / View / one-click AI actions, the AI's plan for your site and an exact step-by-step guide in the dashboard (menu paths for your SEO plugin, with buttons), and when the task counts as done. Mark tasks done, in progress or not relevant.
* The roadmap remembers: every version is stored in the database, the next analysis receives the previous plan and keeps priorities stable unless the data really changed, and shows what changed (new, solved, priority changes with the reason). Done tasks come back only when the problem grows again.
* Non-intrusive AI editing: optimizing a text (also Elementor widgets), a product or a title/description no longer keeps a big popup open. A small card in the corner shows what is being edited and the progress; when it finishes it stays until you close it, with the score change, what was changed (ticked list) and a button to open the full report and apply. Cards survive a page reload.

= 1.6.0 =
* New "Server & speed" page (Connections): choose whether your host is in Iran or abroad, pick the route for AI requests (Auto, Direct, Cloudflare, GitHub) and run a live speed test of every route.
* Iran: AI requests (Claude, ChatGPT/OpenAI, Gemini, OpenRouter, custom APIs) and Google services (Search Console, PageSpeed, Google sign-in, SerpApi) travel through your own Cloudflare worker (synchronous, encrypted) or your private GitHub runner, whichever is fastest and working; never direct. The page explains why (sanctions and filtering).
* Abroad: direct by default; a relay is used automatically only when the direct connection fails. Every route can be chosen manually in both cases, and a failing route automatically falls through to the next one.
* Cloudflare worker: new encrypted /proxy (AES-256-GCM + HMAC, https only, no private networks, nothing stored). Outdated workers are redeployed automatically after a plugin update.
* GitHub runner: new "http" engine for API requests, queue checks every 2 seconds instead of 10, stays warm for a configurable time (default 10 minutes), a run that is already warm is reused instead of starting a new one, and the chat / optimize button start the runner ahead of time. The admin waits 2.5 s between checks instead of 6 s.
* Storage on GitHub is on by default for every host: AI logs, chats, 404 logs, learnings, experiments, knowledge notes and weekly competitor snapshots are archived too (plus Search Console data, reports, change history and settings as before), and the host keeps only recent data. Uses the runner repository's seolity-data branch when no separate data repository is set. Table sizes are shown on the page.

= 1.5.0 =
* ARIAGH.SEOLITY branding: new icon, logo, banners and menu icon in the ARIAGH style.
* Simpler navigation: 9 sections instead of 28 menu items; related pages are tabs inside each section (nothing removed, every page keeps its link).
* Subscription AI really deploys now (like ARIAGH AI Writer): one card, one "Deploy now" button. It checks the token type (rejects API keys), creates or repairs the private repository, enables GitHub Actions and the workflow, stores and verifies the secrets on GitHub and activates the engine — with a live checklist and a status read from GitHub.
* GitHub: "Create & set up everything" builds a single private repository (runner + own knowledge + data archive on the seolity-data branch).
* Cloudflare: the connected state is now remembered and shown (account, ID, verified token); account picker when a token sees several accounts; clear message when the Account ID cannot be detected.
* Knowledge collection: "Collect knowledge now" runs a GitHub workflow that learns from SEO sources, your Search Console queries, pages and competitors using your Claude/ChatGPT subscription (or an Anthropic key) and writes a site playbook to GitHub; live status and report; the AI always uses this site's playbook.
* AI everywhere: media modal, Media Library and attachment screens get an AI button for ALT, title, caption and description (with optional hint), a bulk action and optional auto-ALT on upload.
* Content-writing AI tasks now receive market evidence: cached SERP top results and People Also Ask, matching competitor pages (length, FAQ, schema) and this site's Search Console standing.

= 1.4.0 =
* Subscription AI wizard (like ARIAGH AI Writer, simpler): prerequisite check first, then GitHub, optional Cloudflare, the Claude Pro/Max or ChatGPT Plus/Pro account (copyable Windows / macOS commands) and a real test request.
* New "GitHub & data" page: connect with one token (ready link with the right scopes), see owner, scopes and expiry, and create the private runner, knowledge and data repositories in one click each — with manual step-by-step guides, advanced settings and FAQ.
* Own private knowledge repository in one click (bundled knowledge + weekly knowledge builder workflow + optional Anthropic key), or keep the shared one.
* Cloudflare relay: deploys a free worker on your own Cloudflare account from WordPress (KV mailbox, signed requests, workers.dev, cron). Subscription answers arrive faster, local sites work in pull mode, and the background queue runs on time. Built-in diagnostics.
* Custom API rebuilt: service presets (DeepSeek, Groq, Mistral, Together, Fireworks, xAI, Perplexity, Gemini, Cloudflare Workers AI, Azure OpenAI, LM Studio, vLLM, LiteLLM, Anthropic-compatible gateways), OpenAI or Anthropic format, any key method (Bearer, x-api-key, api-key, custom header, query), extra headers and query parameters, model list, automatic structured-output fallback that remembers what works, token parameter, temperature, request preview.
* Connection guide: new entries for Custom API, GitHub, knowledge base, data archive and Cloudflare.

= 1.3.0 =
* Rank Math integration that goes beyond Rank Math Content AI: focus keywords chosen from the Search Console queries each page already ranks for, written to Rank Math's full keyword list (primary + secondary), cannibalization-safe across the whole site, with preview, approval and undo. Also works with Yoast, SEOPress and AIOSEO.
* GSC keyword intelligence for every page (editor, content list, Rank Math page): query coverage in title/description/headings/content, not-covered queries, question queries for FAQ, striking distance, cannibalization, CTR gap, focus keyword audit and an AI keyword strategy.
* Rank Math editor sync (Gutenberg + classic): SEOlity changes appear live in the Rank Math sidebar and are never overwritten on save. Rank Math score in the content list, low-score triage by search demand, pillar content sync, redirection import, social title/description fields.
* New Connection guide: step-by-step bilingual instructions with direct links for every key and account (Claude, OpenAI, Gemini, OpenRouter, Ollama, Claude/ChatGPT subscriptions, GitHub, Search Console OAuth, PageSpeed, SerpApi), plus docs/CONNECT.md and "Guide" links next to each key field.
* Emoji glyphs replaced with line icons everywhere (status marks, priorities, editor buttons, checklists); icon-only buttons have accessible names.

= 1.2.0 =
* New admin design shared with ARIAGH AI Writer: full-width top bar with status chips, grouped sidebar with line icons and AI/Search Console engine cards, icon cards, two-column settings rows with toggle switches, floating save bar, provider cards, blue palette and Vazirmatn font (light by default, dark mode kept).

= 1.1.0 =
* Subscription AI: use your Claude Pro/Max or ChatGPT Plus/Pro plan (official Claude Code / Codex CLI on GitHub Actions in your private repository) instead of an API key. Encrypted job queue, signed callback, local-site mode, automatic waiting in every AI feature.

= 1.0.0 =
* First release.
