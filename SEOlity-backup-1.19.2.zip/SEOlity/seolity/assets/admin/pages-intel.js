/**
 * SEOlity admin pages: Competitors, Experiments, Redirects, 404 Monitor,
 * Schema, Sitemap, Robots.txt, Reports, Alerts.
 */
( function ( w ) {
	'use strict';
	var SL = w.SL;
	var App = SL.app;
	var t = SL.t;
	var h = SL.h;
	var C = SL.config;

	/* ================================================================ Competitors */
	App.pages.competitors = function ( v ) {
		v.appendChild( App.header( t( 'Competitor Intelligence' ), t( 'SEOlity monitors competitor sitemaps and pages (politely, respecting robots.txt), tracks new content and finds content gaps.' ) ) );
		var serpBox = h( 'div' );
		v.appendChild( serpBox );
		App.serpCard( serpBox, function () {
			App.pages.competitors( SL.clear( v ) );
		} );
		if ( App.cap( 'manage' ) ) {
			var name = h( 'input', { class: 'sl-input', placeholder: t( 'Name' ) } );
			var domain = h( 'input', { class: 'sl-input', placeholder: 'competitor.com', dir: 'ltr' } );
			var freq = App.select( [ [ 'daily', t( 'Daily' ) ], [ 'weekly', t( 'Weekly' ) ], [ 'monthly', t( 'Monthly' ) ] ], 'weekly' );
			v.appendChild( App.card( t( 'Add competitor' ), h( 'div', { class: 'sl-toolbar' }, name, domain, freq, App.abtn( t( 'Add' ), function () {
				return SL.api( 'competitors', { body: { name: name.value, domain: domain.value, frequency: freq.value } } ).then( function () {
					SL.toast( t( 'Competitor added. First analysis is running in the background.' ), 'success' );
					App.pages.competitors( SL.clear( v ) );
				} );
			}, 'primary' ) ) ) );
		}
		var list = h( 'div' );
		v.appendChild( list );
		App.load( list, SL.api( 'competitors' ), function ( rows ) {
			if ( ! rows.length ) {
				list.appendChild( SL.empty( t( 'No competitors yet' ), t( 'Add 2–5 real SEO competitors (sites that rank for your keywords).' ) ) );
				return;
			}
			rows.forEach( function ( c ) {
				var s = c.summary || {};
				var ai = s.ai;
				var stats = s.stats || {};
				var body = h( 'div', { class: 'sl-stack' },
					h( 'div', { class: 'sl-kpis sl-kpis--sm' }, App.kpi( t( 'Pages analyzed' ), SL.num( c.crawled, 0 ), null, { sub: t( '%s known', SL.num( c.known, 0 ) ) } ), App.kpi( t( 'New pages' ), SL.num( s.new_pages || 0, 0 ) ), App.kpi( t( 'Avg. words' ), SL.num( stats.avg_words || 0, 0 ) ), App.kpi( t( 'Pages with FAQ' ), SL.num( stats.pages_with_faq || 0, 0 ) ) ),
					ai ? h( 'div', { class: 'sl-competitor-ai' },
						h( 'p', { text: ai.summary } ),
						h( 'div', { class: 'sl-grid-2' },
							h( 'div', null, h( 'h4', { text: t( 'Where they are stronger' ) } ), h( 'ul', null, ai.strengths.map( function ( x ) {
								return h( 'li', null, h( 'strong', { text: x.area + ': ' } ), x.insight, h( 'div', { class: 'sl-muted sl-small', text: x.evidence } ) );
							} ) ) ),
							h( 'div', null, h( 'h4', { text: t( 'Opportunities for you' ) } ), h( 'ul', null, ai.opportunities.map( function ( x ) {
								return h( 'li', { text: x } );
							} ) ), h( 'h4', { text: t( 'Threats' ) } ), h( 'ul', null, ai.threats.map( function ( x ) {
								return h( 'li', { text: x } );
							} ) ) )
						),
						ai.actions && ai.actions.length ? h( 'div', null, h( 'h4', { text: t( 'Recommended actions' ) } ), h( 'ol', null, ai.actions.map( function ( a ) {
							return h( 'li', null, SL.dot( a.priority ), ' ', h( 'strong', { text: a.title } ), h( 'div', { class: 'sl-muted sl-small', text: a.reason } ) );
						} ) ) ) : null
					) : h( 'p', { class: 'sl-muted', text: t( 'AI summary will appear after the analysis finishes (requires an AI provider).' ) } ),
					stats.sections ? h( 'div', null, h( 'h4', { text: t( 'Content sections' ) } ), SL.charts.bars( Object.keys( stats.sections ).slice( 0, 8 ).map( function ( k ) {
						return { label: k, value: stats.sections[ k ] };
					} ) ) ) : null,
					s.gap && s.gap.opportunities ? gapTable( s.gap ) : null
				);
				list.appendChild( App.card( c.name + ' · ' + c.domain, body, { actions: [
					h( 'span', { class: 'sl-muted sl-small', text: t( 'Last analyzed' ) + ': ' + SL.date( c.last_analyzed ) } ),
					h( 'a', { class: 'sl-btn sl-btn--primary sl-btn--sm', href: '#/competitor?id=' + c.id, text: t( 'Open panel' ) } ),
					App.btn( t( 'Pages' ), function () {
						pagesModal( c );
					}, 'sm' ),
					App.cap( 'ai' ) ? App.abtn( t( 'Content gap' ), function () {
						return SL.api( 'competitors/' + c.id + '/gap', { method: 'POST' } ).then( function () {
							App.pages.competitors( SL.clear( v ) );
						} );
					}, 'sm' ) : null,
					App.cap( 'manage' ) ? App.abtn( t( 'Analyze now' ), function () {
						return SL.api( 'competitors/' + c.id + '/analyze', { method: 'POST' } ).then( function () {
							SL.toast( t( 'Analysis queued.' ) );
						} );
					}, 'sm' ) : null,
					App.cap( 'manage' ) ? App.btn( SL.icon( 'trash', 16 ), function () {
						SL.confirm( t( 'Remove this competitor and its data?' ), function () {
							SL.api( 'competitors/' + c.id, { method: 'DELETE' } ).then( function () {
								App.pages.competitors( SL.clear( v ) );
							} ).catch( SL.fail );
						}, true );
					}, 'ghost', { 'aria-label': t( 'Delete' ) } ) : null,
				] } ) );
			} );
		} );

		function gapTable( gap ) {
			return h( 'div', null, h( 'h4', { text: t( 'Content gap opportunities' ) } ), h( 'p', { class: 'sl-small', text: gap.summary } ), App.table( [
				{ label: t( 'Keyword' ), render: function ( o ) {
					return h( 'div', null, h( 'strong', { dir: 'auto', text: o.keyword } ), h( 'div', { class: 'sl-muted sl-small', text: t( o.type ) + ' · ' + t( o.intent ) } ) );
				} },
				{ label: t( 'Suggested page' ), render: function ( o ) {
					return h( 'div', null, h( 'div', { dir: 'auto', text: o.suggested_title } ), h( 'code', { dir: 'ltr', class: 'sl-small', text: o.suggested_url } ) );
				} },
				{ label: t( 'Words' ), render: function ( o ) {
					return SL.num( o.recommended_word_count, 0 );
				} },
				{ label: t( 'Priority' ), render: function ( o ) {
					return SL.priorityBadge( o.priority );
				} },
				{ label: t( 'Brief' ), render: function ( o ) {
					return h( 'details', null, h( 'summary', { text: t( 'Outline' ) } ), h( 'p', { class: 'sl-small', text: 'H1: ' + o.suggested_h1 } ), h( 'ul', { class: 'sl-small' }, o.outline.map( function ( x ) {
						return h( 'li', { text: x } );
					} ) ), SL.chips( o.supporting_keywords ), h( 'p', { class: 'sl-small sl-muted', text: o.reason } ) );
				} },
			], gap.opportunities ) );
		}

		function pagesModal( c ) {
			var m = SL.modal( { title: c.name + ' — ' + t( 'Pages' ), wide: true } );
			var s = h( 'input', { class: 'sl-input', type: 'search', placeholder: t( 'Filter…' ) } );
			var list2 = h( 'div' );
			var load = function () {
				App.load( list2, SL.api( 'competitors/' + c.id + '/pages', { query: { search: s.value } } ), function ( rows ) {
					list2.appendChild( App.table( [
						{ label: t( 'Page' ), render: function ( p ) {
							return h( 'div', null, App.ext( p.url, p.title ), h( 'div', { class: 'sl-muted sl-small sl-clip', dir: 'auto', text: p.meta_description || '' } ) );
						} },
						{ label: t( 'Words' ), render: function ( p ) {
							return SL.num( p.word_count, 0 );
						} },
						{ label: t( 'Schema' ), render: function ( p ) {
							return SL.chips( ( p.schema_types || '' ).split( ',' ).filter( Boolean ) );
						} },
						{ label: 'FAQ', key: 'faq_count' },
						{ label: t( 'First seen' ), render: function ( p ) {
							return SL.date( p.first_seen );
						} },
					], rows ) );
				} );
			};
			s.addEventListener( 'change', load );
			m.body.appendChild( s );
			m.body.appendChild( list2 );
			load();
		}
	};

	/* ================================================================ Experiments */
	App.pages.experiments = function ( v ) {
		v.appendChild( App.header( t( 'SEO Experiments' ), t( 'Every edit becomes an experiment — SEOlity’s own changes and edits made in WordPress or a page builder: equal before/after windows, adjusted by the site-wide trend (control), judged Positive / Negative / Neutral / Inconclusive, down to each query.' ), App.cap( 'manage' ) ? [ App.abtn( SL.il( 'clock', t( 'Analyze the edit history' ), 15 ), function () {
			return SL.api( 'experiments/history', { method: 'POST' } ).then( function () {
				SL.toast( t( 'Past edits (WordPress revisions) within your Search Console period are being measured — the list updates by itself.' ) );
				refreshSoon();
			} );
		}, 'primary' ), App.abtn( t( 'Evaluate now' ), function () {
			return SL.api( 'experiments/evaluate', { method: 'POST' } ).then( function () {
				SL.toast( t( 'Evaluating the due experiments — the list updates by itself.' ) );
				refreshSoon();
			} );
		} ) ] : null ) );
		var brainBox = h( 'div' );
		v.appendChild( brainBox );
		var tries = 0;
		function refreshSoon() {
			tries = 0;
			( function again() {
				setTimeout( function () {
					if ( ! document.body.contains( body ) ) {
						return;
					}
					load();
					brain();
					if ( ++tries < 6 ) {
						again();
					}
				}, 6000 );
			} )();
		}
		function brain() {
			App.load( brainBox, SL.api( 'brain' ), function ( b ) {
				brainBox.appendChild( brainCard( b ) );
			} );
		}
		function brainCard( b ) {
			var KIND = { good: [ 'check-circle', 'sl-brain__obs--good' ], bad: [ 'alert', 'sl-brain__obs--bad' ], info: [ 'info', '' ] };
			var CONF = { high: t( 'sure' ), medium: t( 'fairly sure' ), low: t( 'early signal' ) };
			var ai = b.ai;
			var obs = h( 'ul', { class: 'sl-brain__obs' }, ( b.observations || [] ).map( function ( o ) {
				var k = KIND[ o.kind ] || KIND.info;
				return h( 'li', { class: k[ 1 ] }, SL.icon( k[ 0 ], 16 ), h( 'span', { dir: 'auto', text: o.text } ), h( 'em', { class: 'sl-muted sl-small', text: CONF[ o.confidence ] || '' } ) );
			} ) );
			var think = App.cap( 'ai' ) ? App.abtn( SL.il( 'brain', b.thinking ? t( 'Thinking…' ) : t( 'Think again' ), 15 ), function () {
				return SL.api( 'brain/think', { method: 'POST' } ).then( function () {
					SL.toast( t( 'The AI is thinking about everything it measured — the answer arrives here and as a notification.' ) );
					refreshSoon();
				} );
			}, 'primary', { disabled: b.thinking } ) : null;
			var mind = ai ? h( 'div', { class: 'sl-stack' },
				h( 'div', { class: 'sl-md', dir: 'auto' }, SL.markdown( ai.summary || '' ) ),
				( ai.wins || [] ).length ? h( 'div', { class: 'sl-brain__wins' }, h( 'b', { text: t( 'Going well' ) } ), h( 'ul', null, ai.wins.map( function ( x ) {
					return h( 'li', { dir: 'auto', text: x } );
				} ) ) ) : null,
				( ai.beliefs || [] ).length ? h( 'div', { class: 'sl-mapcards' }, ai.beliefs.map( function ( x ) {
					var col = 'high' === x.confidence ? '#16a34a' : ( 'medium' === x.confidence ? '#2563eb' : '#d97706' );
					return h( 'article', { class: 'sl-mapcard', style: '--c:' + col },
						h( 'div', { class: 'sl-mapcard__head' }, h( 'span', { class: 'sl-mapcard__ic', 'aria-hidden': 'true' }, SL.icon( 'brain', 20 ) ), h( 'div', { class: 'sl-mapcard__titles' }, h( 'b', { class: 'sl-mapcard__title', dir: 'auto', text: x.belief } ), h( 'span', { class: 'sl-muted sl-small', text: CONF[ x.confidence ] || x.confidence } ) ) ),
						h( 'p', { class: 'sl-small', dir: 'auto', text: x.evidence } ),
						x.implication ? h( 'p', { class: 'sl-small', dir: 'auto' }, h( 'b', { text: t( 'So:' ) + ' ' } ), x.implication ) : null
					);
				} ) ) : null,
				( ai.experiments || [] ).length ? h( 'div', null, h( 'b', { text: t( 'Experiments worth running next' ) } ), h( 'ol', null, ai.experiments.map( function ( x ) {
					return h( 'li', { dir: 'auto' }, h( 'b', { text: x.idea } ), h( 'span', { class: 'sl-muted', text: ' — ' + x.why + ( x.measure ? ' · ' + x.measure : '' ) } ) );
				} ) ) ) : null,
				( ai.open_questions || [] ).length ? h( 'details', null, h( 'summary', { text: t( 'Not sure yet' ) } ), h( 'ul', null, ai.open_questions.map( function ( x ) {
					return h( 'li', { dir: 'auto', text: x } );
				} ) ) ) : null,
				ai.strategy ? h( 'p', { dir: 'auto' }, h( 'b', { text: t( 'Strategy to position 1:' ) + ' ' } ), ai.strategy ) : null,
				h( 'p', { class: 'sl-muted sl-small', text: t( 'Thought on %s', SL.date( b.thought_at ) ) } )
			) : h( 'p', { class: 'sl-muted', text: t( 'The AI has not thought about these observations yet — press “Think again”.' ) } );
			return App.card( t( 'The site’s SEO brain — what it has learned' ), h( 'div', { class: 'sl-stack' },
				h( 'h4', { text: t( 'What the AI thinks' ) } ), mind,
				h( 'h4', { text: t( 'Measured from your own data' ) } ), obs.children.length ? obs : SL.empty( t( 'Not enough data yet' ), t( 'Connect Search Console and let it sync a few weeks.' ) )
			), { icon: 'brain', actions: think, sub: t( 'Strict about problems, generous about wins — everything here is used in every AI suggestion.' ) } );
		}
		brain();
		var body = h( 'div' );
		v.appendChild( body );
		var outcomeKind = { positive: 'good', negative: 'bad', neutral: 'default', inconclusive: 'warn' };
		function load() {
			App.load( body, SL.api( 'experiments' ), function ( r ) {
				var s = r.stats;
				body.appendChild( h( 'div', { class: 'sl-kpis' }, App.kpi( t( 'Running' ), SL.num( s.running || 0, 0 ) ), App.kpi( t( 'Positive' ), SL.num( s.positive || 0, 0 ) ), App.kpi( t( 'Negative' ), SL.num( s.negative || 0, 0 ) ), App.kpi( t( 'Neutral' ), SL.num( s.neutral || 0, 0 ) ), App.kpi( t( 'Inconclusive' ), SL.num( s.inconclusive || 0, 0 ) ) ) );

				body.appendChild( App.table( [
					{ label: t( 'Experiment' ), render: function ( e ) {
						return h( 'div', null, h( 'strong', { text: '#' + e.id + ' ' + e.name } ), ' ', SL.badge( 0 === String( e.change_type ).indexOf( 'editor:' ) ? t( 'Edited in WordPress' ) : 'SEOlity', '' ), h( 'div', { class: 'sl-muted sl-small' }, e.url ? App.ext( e.url ) : '' ) );
					} },
					{ label: t( 'Change' ), render: function ( e ) {
						return SL.chips( String( e.change_type ).replace( /^editor:/, '' ).split( '+' ).map( function ( f ) {
							return 'history' === f ? t( 'Past edit' ) : SL.fieldLabel( f );
						} ) );
					} },
					{ label: t( 'Before → After' ), render: function ( e ) {
						var b = e.metrics_before && e.metrics_before.page;
						var a = e.metrics_after && e.metrics_after.page;
						if ( ! b || ! a ) {
							return h( 'span', { class: 'sl-muted', text: t( 'Window: %s days', e.window_days ) } );
						}
						var dl = e.metrics_after.deltas;
						var qs = ( e.metrics_after.queries || [] ).filter( function ( q ) {
							return null !== q.change;
						} ).slice( 0, 6 );
						return h( 'div', { class: 'sl-small' },
							qs.length ? h( 'details', { class: 'sl-exp-q' }, h( 'summary', { text: t( 'Per query (%s)', qs.length ) } ), h( 'ul', null, qs.map( function ( q ) {
								return h( 'li', { dir: 'auto' }, q.query + ': ' + SL.num( q.position_before ) + ' → ' + SL.num( q.position_after ) + ' ', h( 'span', { class: q.change >= 0 ? 'is-up' : 'is-down', text: ( q.change > 0 ? '▲' : q.change < 0 ? '▼' : '' ) + Math.abs( q.change ) } ) );
							} ) ) ) : null,
							h( 'div', null, t( 'Position' ) + ': ' + SL.num( b.position ) + ' → ' + SL.num( a.position ) ),
							h( 'div', null, t( 'CTR' ) + ': ', h( 'span', { class: dl.ctr >= 0 ? 'is-up' : 'is-down', text: SL.pct( dl.ctr ) } ) ),
							h( 'div', null, t( 'Clicks' ) + ': ', h( 'span', { class: dl.clicks >= 0 ? 'is-up' : 'is-down', text: SL.pct( dl.clicks ) } ) ),
							h( 'div', null, t( 'Impressions' ) + ': ', h( 'span', { class: dl.impressions >= 0 ? 'is-up' : 'is-down', text: SL.pct( dl.impressions ) } ) )
						);
					} },
					{ label: t( 'Outcome' ), render: function ( e ) {
						return e.outcome ? h( 'div', null, SL.badge( t( e.outcome ), outcomeKind[ e.outcome ] ), h( 'div', { class: 'sl-muted sl-small', text: t( 'Confidence' ) + ' ' + e.confidence + '%' } ) ) : SL.badge( t( e.status ) );
					} },
					{ label: t( 'Reason' ), render: function ( e ) {
						return h( 'span', { class: 'sl-small', text: e.reason || '' } );
					} },
					{ label: t( 'Started' ), render: function ( e ) {
						return SL.date( e.started_at );
					} },
					{ label: '', render: function ( e ) {
						return App.cap( 'apply' ) && ( e.status === 'evaluated' || e.status === 'running' ) ? App.btn( t( 'Revert' ), function () {
							SL.confirm( t( 'Revert all changes made in this experiment?' ), function () {
								SL.api( 'experiments/' + e.id + '/revert', { method: 'POST' } ).then( function () {
									SL.toast( t( 'Reverted.' ), 'success' );
									load();
								} ).catch( SL.fail );
							}, true );
						}, 'sm' ) : null;
					} },
				], r.items, { empty: t( 'No experiments yet' ), emptyText: t( 'Apply an AI change to a page that gets search traffic — SEOlity measures the result automatically.' ) } ) );
			} );
		}
		load();
	};

	/* ================================================================ Redirects */
	App.pages.redirects = function ( v ) {
		v.appendChild( App.header( t( 'Redirect Manager' ), t( '301 / 302 / 307 / 410 / 451, regex, bulk import/export, chain & loop detection, hit tracking.' ), [ h( 'a', { class: 'sl-btn', href: C.exportUrl + '&what=redirects' }, t( 'Export CSV' ) ) ] ) );
		var f = { search: '', page: 1, per_page: 50 };
		if ( App.cap( 'manage' ) ) {
			var src = h( 'input', { class: 'sl-input', placeholder: '/old-url', dir: 'ltr' } );
			var dst = h( 'input', { class: 'sl-input', placeholder: '/new-url ' + t( 'or' ) + ' https://…', dir: 'ltr' } );
			var type = App.select( [ [ 301, '301 ' + t( 'Permanent' ) ], [ 302, '302 ' + t( 'Temporary' ) ], [ 307, '307' ], [ 308, '308' ], [ 410, '410 ' + t( 'Gone' ) ], [ 451, '451' ] ], 301 );
			var regex = h( 'input', { type: 'checkbox' } );
			v.appendChild( App.card( t( 'Add redirect' ), h( 'div', { class: 'sl-toolbar' }, src, dst, type, h( 'label', { class: 'sl-check' }, regex, t( 'Regex' ) ), App.abtn( t( 'Add' ), function () {
				return SL.api( 'redirects', { body: { source: src.value, target: dst.value, type: type.value, is_regex: regex.checked } } ).then( function () {
					src.value = '';
					dst.value = '';
					load();
				} );
			}, 'primary' ) ), { actions: [ App.btn( t( 'Bulk import' ), function () {
				var m = SL.modal( { title: t( 'Bulk import (CSV)' ) } );
				var ta = h( 'textarea', { class: 'sl-input', rows: 10, dir: 'ltr', placeholder: 'source,target,type,regex\n/old,/new,301,0' } );
				m.body.appendChild( ta );
				m.foot.appendChild( App.abtn( t( 'Import' ), function () {
					return SL.api( 'redirects/import', { body: { csv: ta.value } } ).then( function ( r ) {
						SL.toast( t( '%s redirects imported.', r.created ), 'success' );
						if ( r.errors.length ) {
							SL.toast( t( '%s lines had errors.', r.errors.length ), 'error' );
						}
						m.close();
						load();
					} );
				}, 'primary' ) );
			}, 'sm' ) ] } ) );
		}
		var s = h( 'input', { class: 'sl-input', type: 'search', placeholder: t( 'Search redirects…' ) } );
		s.addEventListener( 'change', function () {
			f.search = s.value;
			load();
		} );
		v.appendChild( h( 'div', { class: 'sl-toolbar' }, s ) );
		var list = h( 'div' );
		v.appendChild( list );
		/** Redirect chains as a picture: today (A → B → C) and after the fix (A → C, B → C). */
		function renderChains( box ) {
			App.load( box, SL.api( 'redirects/chains' ), function ( g ) {
				if ( ! g.count ) {
					return;
				}
				var after = false;
				var lanes = h( 'div', { class: 'sl-chains__lanes' } );
				function node( p, isFinal, isLoop ) {
					var n = g.nodes[ p ] || { path: p };
					return h( 'span', { class: 'sl-chain__node' + ( isFinal ? ' is-final' : '' ) + ( isLoop ? ' is-loop' : '' ) + ( n.is_page ? ' is-page' : '' ), title: ( n.title ? n.title + '\n' : '' ) + ( n.label || t( 'Only a redirect' ) ) + ( n.clicks_28d ? '\n' + t( '%s clicks (28 days)', n.clicks_28d ) : '' ) },
						h( 'code', { dir: 'ltr', text: decodeURI( p ) } ),
						n.title ? h( 'small', { dir: 'auto', text: n.title } ) : null,
						n.label ? h( 'small', { class: 'sl-chain__imp sl-chain__imp--' + n.importance, text: n.label } ) : null
					);
				}
				function arrow() {
					return h( 'span', { class: 'sl-chain__arrow', 'aria-hidden': 'true' } );
				}
				function draw() {
					SL.clear( lanes );
					g.chains.forEach( function ( c ) {
						var paths = c.chain;
						var last = paths[ paths.length - 1 ];
						var lane = h( 'div', { class: 'sl-chain' + ( c.loop ? ' is-loop' : '' ) + ( after && ! c.loop ? ' is-after' : '' ) } );
						if ( ! after || c.loop ) {
							paths.forEach( function ( p, i ) {
								if ( i ) {
									lane.appendChild( arrow() );
								}
								lane.appendChild( node( p, ! c.loop && i === paths.length - 1, c.loop && i === paths.length - 1 ) );
							} );
							if ( c.loop ) {
								lane.appendChild( h( 'span', { class: 'sl-chain__loopmark', text: '↺ ' + t( 'loop' ) } ) );
								if ( after ) {
									lane.appendChild( h( 'span', { class: 'sl-muted sl-small', text: t( 'A loop has no end: let the AI choose which real page answers.' ) } ) );
								}
							}
						} else {
							// After: every old address goes straight to the final page.
							var olds = h( 'div', { class: 'sl-chain__olds' }, paths.slice( 0, -1 ).map( function ( p ) {
								return h( 'div', { class: 'sl-chain__row' }, node( p, false, false ), arrow() );
							} ) );
							lane.appendChild( olds );
							lane.appendChild( node( last, true, false ) );
						}
						lanes.appendChild( lane );
					} );
				}
				var toggle = h( 'div', { class: 'sl-seg' },
					h( 'button', { type: 'button', class: 'is-active', onClick: function ( e ) {
						after = false;
						e.target.classList.add( 'is-active' );
						e.target.nextSibling.classList.remove( 'is-active' );
						draw();
					} }, t( 'Today' ) ),
					h( 'button', { type: 'button', class: '', onClick: function ( e ) {
						after = true;
						e.target.classList.add( 'is-active' );
						e.target.previousSibling.classList.remove( 'is-active' );
						draw();
					} }, t( 'After the fix' ) )
				);
				function review( ai ) {
					var m = SL.modal( { title: ai ? t( 'AI chooses the best final page' ) : t( 'Point every step to the final page' ), wide: true, onClose: load } );
					var instr = ai ? h( 'textarea', { class: 'sl-input', rows: 2, dir: 'auto', placeholder: t( 'Optional rule, e.g. “old product addresses go to their category”, “prefer the shop page”.' ) } ) : null;
					var opbox = h( 'div' );
					m.body.appendChild( h( 'p', { class: 'sl-muted', text: ai ? t( 'For each chain the AI picks, from checked live pages only, the final page that matches the old addresses best and matters most for the site (importance, real clicks) — usually where the chain ends, sometimes a stronger page like the shop or a category. You approve every redirect.' ) : t( 'Every old address will redirect in one step to the page its chain ends on. You approve every redirect; each is checked on the live site and can be undone.' ) } ) );
					if ( instr ) {
						m.body.appendChild( instr );
					}
					m.body.appendChild( opbox );
					opbox.appendChild( App.abtn( t( 'Prepare the fix' ), function () {
						return SL.api( 'redirects/chains/review', { body: { ai: ai ? 1 : 0, instructions: instr ? instr.value : '' } } ).then( function ( op ) {
							if ( instr ) {
								instr.remove();
							}
							App.operationView( opbox, op, load );
						} );
					}, 'primary' ) );
				}
				box.appendChild( h( 'section', { class: 'sl-panel sl-chains' },
					h( 'div', { class: 'sl-chains__head' },
						h( 'div', null,
							h( 'h3', { class: 'sl-panel__title', text: t( 'Redirect chains' ) } ),
							h( 'p', { class: 'sl-muted sl-small', text: t( '%1$s chains (%2$s loops) with %3$s redirects. Each extra step costs visitors and Googlebot one more request and loses a little signal; a loop is a dead end. Worth fixing, rarely an emergency.', g.count, g.loops, g.hops ) } )
						),
						toggle
					),
					lanes,
					App.cap( 'manage' ) ? h( 'div', { class: 'sl-row' },
						App.btn( SL.il( 'wand', t( 'AI chooses the best final page' ), 15 ), function () {
							review( true );
						}, 'primary' ),
						App.btn( t( 'Point every step to the final page' ), function () {
							review( false );
						} )
					) : null
				) );
				draw();
			} );
		}
		function load() {
			App.load( list, SL.api( 'redirects', { query: f } ), function ( r ) {
				var chainBox = h( 'div' );
				list.appendChild( chainBox );
				if ( r.chains.length ) {
					renderChains( chainBox );
				}
				list.appendChild( App.table( [
					{ label: t( 'From' ), render: function ( x ) {
						return h( 'code', { dir: 'ltr', text: ( +x.is_regex ? '~ ' : '' ) + x.source } );
					} },
					{ label: t( 'To' ), render: function ( x ) {
						return x.target ? h( 'code', { dir: 'ltr', text: SL.path( x.target ) } ) : '—';
					} },
					{ label: t( 'Type' ), key: 'type' },
					{ label: t( 'Hits' ), render: function ( x ) {
						return SL.num( x.hits, 0 );
					} },
					{ label: t( 'Last used' ), render: function ( x ) {
						return SL.date( x.last_hit );
					} },
					{ label: t( 'Origin' ), render: function ( x ) {
						return t( x.origin );
					} },
					{ label: t( 'Status' ), render: function ( x ) {
						if ( ! App.cap( 'manage' ) ) {
							return t( x.status );
						}
						var cb = h( 'input', { type: 'checkbox', checked: x.status === 'active', 'aria-label': t( 'Active' ), onChange: function () {
							SL.api( 'redirects/' + x.id, { method: 'PUT', body: { status: cb.checked ? 'active' : 'disabled' } } ).catch( SL.fail );
						} } );
						return cb;
					} },
					{ label: '', render: function ( x ) {
						return App.cap( 'manage' ) ? App.btn( SL.icon( 'trash', 16 ), function () {
							SL.confirm( t( 'Delete this redirect?' ), function () {
								SL.api( 'redirects/' + x.id, { method: 'DELETE' } ).then( load ).catch( SL.fail );
							}, true );
						}, 'ghost', { 'aria-label': t( 'Delete' ) } ) : null;
					} },
				], r.items, { empty: t( 'No redirects yet' ) } ) );
				SL.append( list, App.pager( r.total, f.page, f.per_page, function ( p ) {
					f.page = p;
					load();
				} ) );
			} );
		}
		load();
	};

	/* ================================================================ 404 Monitor */
	App.pages[ '404' ] = function ( v ) {
		v.appendChild( App.header( t( '404 Monitor' ), t( 'Every 404 is logged with referrer and hits; SEOlity suggests the best redirect target (slug similarity + AI).' ), App.cap( 'ai' ) ? [ App.abtn( SL.il( 'wand', t( 'AI review: 301, 410 or leave?' ), 15 ), function () {
			var m = SL.modal( { title: t( 'AI review of 404 errors' ), wide: true, onClose: load } );
			var instr = h( 'textarea', { class: 'sl-input', rows: 2, dir: 'auto', placeholder: t( 'Optional instructions, e.g. “old product URLs go to their category”, “never redirect to the home page”.' ) } );
			var box = h( 'div' );
			m.body.appendChild( h( 'p', { class: 'sl-muted', text: t( 'The AI judges every open 404 from real evidence — Search Console clicks and impressions, internal links still pointing to it, external referrers, human or Googlebot requests, deleted posts and how close each candidate page is — and decides: 301 to an equivalent page (to keep its rankings), 410 when it is gone for good, or leave it as 404 when it has no value. It also tells you honestly whether these 404s cost crawl budget on a site of your size. Nothing changes until you approve.' ) } ) );
			m.body.appendChild( instr );
			m.body.appendChild( box );
			box.appendChild( h( 'div', { class: 'sl-row' }, App.abtn( t( 'Start the review' ), function () {
				return SL.api( '404/triage', { body: { instructions: instr.value } } ).then( function ( op ) {
					instr.remove();
					App.operationView( box, op, load );
				} );
			}, 'primary' ) ) );
			return Promise.resolve();
		}, 'primary' ), App.abtn( t( 'Suggest targets' ), function () {
			return SL.api( '404/suggest', { method: 'POST' } ).then( function () {
				SL.toast( t( 'Computing suggestions in the background.' ) );
			} );
		} ) ] : null ) );
		var f = { status: 'open', search: '', page: 1, per_page: 50 };
		var body = h( 'div' );
		v.appendChild( body );
		function load() {
			App.load( body, SL.api( '404', { query: f } ), function ( r ) {
				body.appendChild( h( 'div', { class: 'sl-kpis' }, App.kpi( t( 'To review' ), SL.num( r.stats.open, 0 ) ), App.kpi( t( 'With real value' ), SL.num( r.stats.important || 0, 0 ) ), App.kpi( t( 'Hidden: not important' ), SL.num( r.stats.noise || 0, 0 ) ), App.kpi( t( 'Hits (7 days)' ), SL.num( r.stats.hits_7d, 0 ) ), App.kpi( t( 'New (24h)' ), SL.num( r.stats.new_24h, 0 ) ) ) );
				if ( r.stats.sorting ) {
					body.appendChild( h( 'div', { class: 'sl-alert sl-alert--info' }, t( 'Sorting %s new URLs by real evidence (Search Console history, links, referrers, Googlebot). Scanner probes without any value are moved to “Hidden: not important”.', r.stats.sorting ) ) );
					setTimeout( function () {
						if ( document.body.contains( body ) ) {
							load();
						}
					}, 8000 );
				}
				// Bulk: each selected URL goes to its own (editable) target.
				var sel = {};
				var targets = {};
				var boxes = [];
				var rowsById = {};
				( r.items || [] ).forEach( function ( x ) {
					rowsById[ x.id ] = x;
				} );
				var bulkOn = ( 'open' === f.status || 'noise' === f.status ) && App.cap( 'manage' );
				var counter = h( 'span', { class: 'sl-muted sl-small', text: '' } );
				function chosen() {
					return Object.keys( sel ).filter( function ( k ) {
						return sel[ k ];
					} ).map( Number );
				}
				function count() {
					var n = chosen().length;
					counter.textContent = n ? t( '%s selected', n ) : '';
					bulkBtns.forEach( function ( b ) {
						b.disabled = ! n;
					} );
				}
				function status( st ) {
					return SL.api( '404/bulk-status', { body: { ids: chosen(), status: st } } ).then( function ( x ) {
						SL.toast( 'open' === st ? t( '%s URLs are back in the list.', x.updated ) : t( '%s URLs hidden as not important.', x.updated ), 'success' );
						load();
					} );
				}
				var bulkBtn = App.abtn( SL.il( 'corner', t( 'Redirect selected to their own targets' ), 15 ), function () {
					var items = chosen().map( function ( k ) {
						return { id: k, target: targets[ k ] ? targets[ k ].value.trim() : '' };
					} );
					return SL.api( '404/bulk-redirect', { body: { items: items } } ).then( function ( op ) {
						var m = SL.modal( { title: op.title, wide: true, onClose: load } );
						m.body.appendChild( h( 'p', { class: 'sl-muted', text: t( 'Every redirect was checked: the target must be a live page, no loop may be created and the old URL must really be gone. Untick anything you do not want, then approve.' ) } ) );
						var box = h( 'div' );
						m.body.appendChild( box );
						App.operationView( box, op, load );
					} );
				}, 'primary', { disabled: true } );
				var askBtn = App.btn( SL.il( 'bot', t( 'Ask the AI about these' ), 15 ), function () {
					var ids = chosen();
					App.state.chatPackage = { type: '404', ids: ids, count: ids.length, sample: ids.slice( 0, 4 ).map( function ( k ) {
						return rowsById[ k ] ? rowsById[ k ].url : '';
					} ) };
					App.go( '#/ai' );
				}, 'sm', { disabled: true } );
				var decideBtn = App.cap( 'ai' ) ? App.btn( SL.il( 'wand', t( 'Let the AI decide for these' ), 15 ), function () {
					var ids = chosen();
					var m = SL.modal( { title: t( 'AI review of the selected URLs' ), wide: true, onClose: load } );
					var instr = h( 'textarea', { class: 'sl-input', rows: 2, dir: 'auto', placeholder: t( 'Your rule, e.g. “if they do not matter for rankings, hide them; real pages get a 301”.' ) } );
					var box = h( 'div' );
					m.body.appendChild( h( 'p', { class: 'sl-muted', text: t( 'The AI judges only these %s URLs from real evidence and prepares 301 / 410 / leave decisions for your approval; URLs without any value are hidden from the list.', ids.length ) } ) );
					m.body.appendChild( instr );
					m.body.appendChild( box );
					box.appendChild( App.abtn( t( 'Start the review' ), function () {
						return SL.api( '404/triage', { body: { instructions: instr.value, ids: ids } } ).then( function ( op ) {
							instr.remove();
							App.operationView( box, op, load );
						} );
					}, 'primary' ) );
				}, 'sm', { disabled: true } ) : null;
				var hideBtn = App.abtn( 'noise' === f.status ? t( 'Bring back to the list' ) : t( 'Hide as not important' ), function () {
					return status( 'noise' === f.status ? 'open' : 'noise' );
				}, 'sm', { disabled: true } );
				var bulkBtns = [ hideBtn, askBtn ].concat( decideBtn ? [ decideBtn ] : [] ).concat( 'open' === f.status ? [ bulkBtn ] : [] );
				var all = h( 'input', { type: 'checkbox', 'aria-label': t( 'Select all' ), title: t( 'Select all' ), onChange: function ( e ) {
					boxes.forEach( function ( b ) {
						b.checked = e.target.checked;
						sel[ b.value ] = e.target.checked;
					} );
					count();
				} } );
				var noTarget = 'open' === f.status ? App.btn( t( 'Select the ones without a suggestion' ), function () {
					boxes.forEach( function ( b ) {
						var x = rowsById[ b.value ];
						b.checked = !! x && ! x.suggested_target;
						sel[ b.value ] = b.checked;
					} );
					count();
				}, 'sm' ) : null;
				body.appendChild( h( 'div', { class: 'sl-toolbar' }, App.select( [ [ 'open', t( 'To review' ) + ' (' + SL.num( r.stats.open, 0 ) + ')' ], [ 'noise', t( 'Hidden: not important' ) + ' (' + SL.num( r.stats.noise || 0, 0 ) + ')' ], [ 'redirected', t( 'Redirected' ) ], [ 'ignored', t( 'Ignored' ) ] ], f.status, function ( x ) {
					f.status = x;
					f.page = 1;
					load();
				} ), bulkOn ? noTarget : null, bulkOn ? counter : null ) );
				if ( bulkOn ) {
					body.appendChild( h( 'div', { class: 'sl-toolbar sl-404-bulk' }, bulkBtns ) );
				}
				if ( 'noise' === f.status ) {
					body.appendChild( h( 'p', { class: 'sl-muted sl-small', text: t( 'These URLs have no value for search: no Search Console history, no page links to them, no real visitor came from anywhere — mostly security scanners. A 404 is the right answer and does not hurt rankings. Nothing on the site was changed; bring any of them back if you disagree.' ) } ) );
				}
				body.appendChild( App.table( [
					bulkOn ? { label: all, render: function ( x ) {
						var b = h( 'input', { type: 'checkbox', value: String( x.id ), 'aria-label': t( 'Select' ), onChange: function ( e ) {
							sel[ x.id ] = e.target.checked;
							count();
						} } );
						boxes.push( b );
						return b;
					} } : null,
					{ label: t( 'URL' ), render: function ( x ) {
						var badge = x.verdict === 'important' ? SL.badge( t( 'Has value' ), 'good' ) : null;
						return h( 'div', { class: 'sl-404-url' }, h( 'code', { dir: 'ltr', text: x.url } ), badge, x.verdict_reason ? h( 'small', { class: 'sl-muted sl-404-why', dir: 'auto', text: x.verdict_reason } ) : null );
					} },
					{ label: t( 'Referrer' ), render: function ( x ) {
						return x.referrer ? App.ext( x.referrer ) : '—';
					} },
					{ label: t( 'Hits' ), render: function ( x ) {
						return SL.num( x.hits, 0 );
					} },
					{ label: t( 'First seen' ), render: function ( x ) {
						return SL.date( x.first_seen );
					} },
					{ label: t( 'Last seen' ), render: function ( x ) {
						return SL.date( x.last_seen );
					} },
					{ label: t( 'Suggested redirect' ), render: function ( x ) {
						if ( bulkOn ) {
							targets[ x.id ] = h( 'input', { class: 'sl-input sl-input--sm', dir: 'ltr', value: x.suggested_target ? decodeURI( x.suggested_target ) : '', placeholder: x.suggested_target === '' ? t( 'no good match — enter a target' ) : t( 'pending' ) } );
							return h( 'div', { class: 'sl-stack' }, targets[ x.id ], x.suggested_target ? h( 'small', { class: 'sl-muted', text: t( 'match %s%', x.suggestion_score || 0 ) } ) : null );
						}
						return x.suggested_target ? h( 'div', null, App.ext( x.suggested_target ), h( 'small', { class: 'sl-muted', text: ' ' + ( x.suggestion_score || 0 ) + '%' } ) ) : h( 'span', { class: 'sl-muted', text: x.suggested_target === '' ? t( 'no good match' ) : t( 'pending' ) } );
					} },
					{ label: '', render: function ( x ) {
						if ( App.cap( 'manage' ) && x.status === 'noise' ) {
							return App.btn( t( 'Bring back' ), function () {
								SL.api( '404/' + x.id + '/status', { body: { status: 'open' } } ).then( load ).catch( SL.fail );
							}, 'sm' );
						}
						if ( ! App.cap( 'manage' ) || x.status !== 'open' ) {
							return null;
						}
						return h( 'div', { class: 'sl-row' },
							App.btn( t( 'Redirect' ), function () {
								App.handleResult( { preview: { type: 'redirect', source: x.url, target: x.suggested_target || '', candidates: [] } }, load );
							}, x.suggested_target ? 'primary' : 'sm' ),
							App.btn( t( '410 Gone' ), function () {
								SL.api( 'redirects', { body: { source: x.url, target: '', type: 410 } } ).then( function () {
									SL.toast( t( 'Marked as gone (410).' ) );
									load();
								} ).catch( SL.fail );
							}, 'sm' ),
							App.btn( t( 'Ignore' ), function () {
								SL.api( '404/' + x.id + '/status', { body: { status: 'ignored' } } ).then( load ).catch( SL.fail );
							}, 'sm' )
						);
					} },
				], r.items, { empty: t( 'No 404 errors logged' ) } ) );
				SL.append( body, App.pager( r.total, f.page, f.per_page, function ( p ) {
					f.page = p;
					load();
				} ) );
			} );
		}
		load();
	};

	/* ================================================================ Schema */
	App.pages.schema = function ( v ) {
		v.appendChild( App.header( t( 'Schema Intelligence' ), t( 'Validate Product, Article, FAQ, Breadcrumb, Organization, LocalBusiness, Review, AggregateRating, WebSite, WebPage and Person markup; find missing opportunities.' ) ) );
		var url = h( 'input', { class: 'sl-input', type: 'url', placeholder: C.homeUrl, dir: 'ltr' } );
		var result = h( 'div' );
		var list = function ( title, items, kind ) {
			return items && items.length ? h( 'div', { class: 'sl-alert sl-alert--' + kind }, h( 'strong', { text: title } ), h( 'ul', null, items.map( function ( x ) {
				return h( 'li', { dir: 'auto', text: x } );
			} ) ) ) : null;
		};
		var render = function ( r ) {
			SL.clear( result );
			result.appendChild( h( 'div', { class: 'sl-stack' },
				h( 'div', null, h( 'strong', { text: t( 'Types found' ) + ': ' } ), SL.chips( r.types ) ),
				r.invalid_json ? h( 'div', { class: 'sl-alert sl-alert--error', text: t( '%s JSON-LD blocks contain invalid JSON.', r.invalid_json ) } ) : null,
				r.errors.length ? list( t( 'Errors' ), r.errors.map( function ( e ) {
					return e.message;
				} ), 'error' ) : h( 'div', { class: 'sl-alert sl-alert--success', text: t( 'No required properties missing.' ) } ),
				r.warnings.length ? h( 'details', null, h( 'summary', { text: t( 'Warnings (%s)', r.warnings.length ) } ), h( 'ul', null, r.warnings.map( function ( e ) {
					return h( 'li', { text: e.message } );
				} ) ) ) : null,
				list( t( 'Opportunities' ), r.opportunities, 'info' ),
				r.ai ? h( 'div', { class: 'sl-card sl-card--inset' }, h( 'h3', { class: 'sl-iconline' }, SL.il( 'sparkles', t( 'AI schema suggestions' ), 17 ) ),
					h( 'div', null, h( 'strong', { text: t( 'Eligible types' ) + ': ' } ), SL.chips( r.ai.eligible_types ) ),
					list( t( 'Issues' ), r.ai.issues, 'warn' ),
					list( t( 'Opportunities' ), r.ai.opportunities, 'info' ),
					h( 'p', { class: 'sl-small sl-muted', text: t( 'Only mark up information that is visible on the page.' ) } )
				) : null,
				h( 'details', null, h( 'summary', { text: t( 'Raw JSON-LD' ) } ), h( 'pre', { class: 'sl-json', dir: 'ltr', text: JSON.stringify( r.blocks, null, 2 ) } ) )
			) );
		};
		var actions = [ App.abtn( t( 'Check structured data' ), function () {
			return SL.api( 'schema/check', { body: { url: url.value || C.homeUrl } } ).then( render );
		}, 'primary' ) ];
		if ( App.cap( 'ai' ) ) {
			actions.push( App.abtn( SL.il( 'sparkles', t( 'AI schema suggestions' ) ), function () {
				return SL.api( 'schema/suggest', { body: { url: url.value || C.homeUrl } } ).then( render );
			} ) );
		}
		v.appendChild( App.card( t( 'Validate a URL' ), h( 'div', null, h( 'div', { class: 'sl-toolbar' }, [ url ].concat( actions ) ), result ) ) );
		var cov = h( 'div' );
		v.appendChild( cov );
		App.load( cov, SL.api( 'schema' ), function ( r ) {
			cov.appendChild( h( 'div', { class: 'sl-grid-2' },
				App.card( t( 'Schema coverage' ), h( 'div', null, h( 'p', { class: 'sl-muted', text: t( '%1$s of %2$s indexable pages have no structured data.', SL.num( r.without, 0 ), SL.num( r.pages, 0 ) ) } ), SL.charts.bars( Object.keys( r.types ).slice( 0, 12 ).map( function ( k ) {
					return { label: k, value: r.types[ k ] };
				} ), { colorBy: true } ) ) ),
				App.card( t( 'Schema issues' ), h( 'div', null, App.table( [ { label: t( 'Issue' ), key: 'check_code' }, { label: t( 'Pages' ), key: 'c' } ], r.issues, { empty: t( 'No schema issues' ) } ), h( 'p', { class: 'sl-small', text: r.outputs ? t( 'SEOlity outputs Organization, WebSite, WebPage, Breadcrumb and Article schema.' ) : t( 'Another SEO plugin outputs your main schema; SEOlity adds FAQ schema only.' ) } ), h( 'p', { class: 'sl-small', text: t( 'Pages with SEOlity FAQ schema' ) + ': ' + SL.num( r.faq_pages, 0 ) } ), App.link( t( 'Organization settings' ), 'settings?tab=schema' ) ) )
			) );
		} );
	};

	/* ================================================================ Sitemap */
	App.sitemapHealth = function ( v ) {
		v.appendChild( App.header( t( 'Sitemap Intelligence' ), t( 'Checks every sitemap URL against crawl data: 404s, redirects, noindex and canonicalized URLs, missing important pages and lastmod quality.' ), [ App.abtn( t( 'Re-check' ), function () {
			return SL.api( 'sitemap', { query: { fresh: 1 } } ).then( function () {
				App.sitemapHealth( SL.clear( v ) );
			} );
		} ) ] ) );
		var body = h( 'div' );
		v.appendChild( body );
		App.load( body, SL.api( 'sitemap' ), function ( r ) {
			body.appendChild( h( 'div', { class: 'sl-kpis' }, App.kpi( t( 'Sitemaps' ), SL.num( r.sitemaps.length, 0 ) ), App.kpi( t( 'URLs in sitemaps' ), SL.num( r.total_urls, 0 ) ), App.kpi( t( 'Problem URLs' ), SL.num( r.problem_urls.length, 0 ) ), App.kpi( t( 'Missing important pages' ), SL.num( r.missing_urls.length, 0 ) ) ) );
			if ( r.recommendations.length ) {
				body.appendChild( App.card( t( 'Recommendations' ), h( 'ul', null, r.recommendations.map( function ( x ) {
					return h( 'li', { text: x } );
				} ) ) ) );
			}
			body.appendChild( App.card( t( 'Sitemaps' ), App.table( [ { label: t( 'Sitemap' ), render: function ( s ) {
				return App.ext( s.url );
			} }, { label: t( 'Type' ), key: 'type' }, { label: t( 'Status' ), key: 'status' }, { label: t( 'Entries' ), key: 'count' }, { label: 'lastmod', key: 'with_lastmod' }, { label: t( 'Error' ), key: 'error' } ], r.sitemaps ), { actions: r.gsc && App.cap( 'manage' ) ? [ App.abtn( t( 'Submit to Google' ), function () {
				return SL.api( 'sitemap/submit', { body: { url: r.sitemaps[ 0 ] ? r.sitemaps[ 0 ].url : '' } } ).then( function () {
					SL.toast( t( 'Sitemap submitted to Search Console.' ), 'success' );
				} );
			} ) ] : null } ) );
			if ( r.gsc && Array.isArray( r.gsc ) ) {
				body.appendChild( App.card( t( 'Search Console sitemap status' ), App.table( [ { label: t( 'Sitemap' ), render: function ( s ) {
					return App.ext( s.path );
				} }, { label: t( 'Last downloaded' ), render: function ( s ) {
					return SL.date( s.lastDownloaded );
				} }, { label: t( 'Errors' ), key: 'errors' }, { label: t( 'Warnings' ), key: 'warnings' } ], r.gsc ) ) );
			}
			body.appendChild( h( 'div', { class: 'sl-grid-2' },
				App.card( t( 'Remove from sitemap' ), App.table( [ { label: t( 'URL' ), render: function ( p ) {
					return App.ext( p.url );
				} }, { label: t( 'Reason' ), render: function ( p ) {
					return SL.badge( t( p.reason ), 'warn' );
				} } ], r.problem_urls.slice( 0, 100 ), { empty: t( 'Sitemap is clean' ) } ) ),
				App.card( t( 'Add to sitemap (indexable pages missing)' ), App.table( [ { label: t( 'URL' ), render: function ( p ) {
					return App.ext( p.url );
				} }, { label: t( 'Inlinks' ), key: 'inlinks' } ], r.missing_urls, { empty: t( 'Nothing missing' ) } ) )
			) );
		} );
	};

	/* ================================================================ Robots */
	App.pages.robots = function ( v ) {
		v.appendChild( App.header( t( 'Robots.txt Intelligence' ), t( 'Google-compatible rule matching, blocked important URLs, crawl-waste detection and a safe editor with live testing.' ) ) );
		var body = h( 'div' );
		v.appendChild( body );
		App.load( body, SL.api( 'robots' ), function ( r ) {
			var ta = h( 'textarea', { class: 'sl-input sl-code', rows: 16, dir: 'ltr', spellcheck: 'false' } );
			ta.value = r.override ? r.custom : r.content;
			var override = h( 'input', { type: 'checkbox', checked: r.override } );
			var testUrl = h( 'input', { class: 'sl-input', type: 'url', dir: 'ltr', placeholder: C.homeUrl + 'shop/?orderby=price' } );
			var testOut = h( 'div' );
			if ( r.physical_file ) {
				body.appendChild( h( 'div', { class: 'sl-alert sl-alert--warn', text: t( 'A physical robots.txt file exists in your web root; WordPress (and SEOlity) cannot override it. Edit or delete that file.' ) } ) );
			}
			body.appendChild( h( 'div', { class: 'sl-grid-2' },
				App.card( t( 'Editor' ), h( 'div', { class: 'sl-stack' }, ta, h( 'label', { class: 'sl-check' }, override, t( 'Serve this content as robots.txt (virtual)' ) ), h( 'div', { class: 'sl-row' }, App.cap( 'manage' ) ? App.abtn( t( 'Save' ), function () {
					return SL.api( 'robots', { body: { content: ta.value, override: override.checked } } ).then( function () {
						SL.toast( t( 'robots.txt saved.' ), 'success' );
						App.pages.robots( SL.clear( v ) );
					} );
				}, 'primary' ) : null, App.btn( t( 'Load suggested' ), function () {
					ta.value = r.suggested;
				} ) ), h( 'div', { class: 'sl-toolbar' }, testUrl, App.abtn( t( 'Test URL' ), function () {
					return SL.api( 'robots/test', { body: { url: testUrl.value, content: ta.value } } ).then( function ( x ) {
						SL.clear( testOut );
						testOut.appendChild( SL.chips( [ [ SL.yes( x.googlebot, 14 ), ' Googlebot: ' + ( x.googlebot ? t( 'allowed' ) : t( 'blocked' ) ) ], [ SL.yes( x.bingbot, 14 ), ' Bingbot' ], [ SL.yes( x.any, 14 ), ' *' ] ] ) );
					} );
				} ) ), testOut ) ),
				h( 'div', null,
					App.card( t( 'Issues' ), r.issues.length ? h( 'ul', { class: 'sl-list' }, r.issues.map( function ( i ) {
						return h( 'li', null, SL.priorityBadge( i.severity ), ' ', i.message );
					} ) ) : SL.empty( t( 'No issues' ) ) ),
					App.card( t( 'Crawl-waste suggestions' ), r.suggestions.length ? h( 'ul', null, r.suggestions.map( function ( s ) {
						return h( 'li', { dir: 'auto', text: s } );
					} ) ) : SL.empty( t( 'Nothing to suggest' ) ) ),
					r.blocked_important.length ? App.card( t( 'Important URLs blocked' ), h( 'ul', { class: 'sl-urls' }, r.blocked_important.map( function ( u ) {
						return h( 'li', null, App.ext( u ) );
					} ) ) ) : null
				)
			) );
		} );
	};

	/* ================================================================ Reports */
	App.pages.reports = function ( v ) {
		v.appendChild( App.header( t( 'SEO Reports' ), t( 'Daily, weekly and monthly reports with traffic, rankings, issues, improvements, competitors, AI changes and recommendations — white-label ready.' ) ) );
		var type = App.select( [ [ 'daily', t( 'Daily' ) ], [ 'weekly', t( 'Weekly' ) ], [ 'monthly', t( 'Monthly' ) ] ], 'weekly' );
		var list = h( 'div' );
		v.appendChild( App.card( t( 'Generate report' ), h( 'div', { class: 'sl-toolbar' }, type, App.abtn( t( 'Generate' ), function () {
			return SL.api( 'reports/generate', { body: { type: type.value } } ).then( function () {
				SL.toast( t( 'Report generated.' ), 'success' );
				load();
			} );
		}, 'primary' ), App.link( t( 'Schedule & recipients' ), 'settings?tab=reports' ) ) ) );
		v.appendChild( list );
		function load() {
			App.load( list, SL.api( 'reports' ), function ( rows ) {
				list.appendChild( App.table( [
					{ label: t( 'Report' ), key: 'title' },
					{ label: t( 'Type' ), render: function ( r ) {
						return t( r.type );
					} },
					{ label: t( 'Period' ), render: function ( r ) {
						return SL.date( r.period_start ) + ' – ' + SL.date( r.period_end );
					} },
					{ label: t( 'Storage' ), render: function ( r ) {
						return r.archive_ref ? SL.badge( 'GitHub', 'brand' ) : SL.badge( t( 'Local' ) );
					} },
					{ label: t( 'Export' ), render: function ( r ) {
						return h( 'div', { class: 'sl-row' }, h( 'a', { class: 'sl-btn sl-btn--sm', target: '_blank', rel: 'noopener', href: C.exportUrl + '&id=' + r.id + '&format=html' }, t( 'View / PDF' ) ), h( 'a', { class: 'sl-btn sl-btn--sm', href: C.exportUrl + '&id=' + r.id + '&format=csv' }, 'CSV' ), h( 'a', { class: 'sl-btn sl-btn--sm', href: C.exportUrl + '&id=' + r.id + '&format=json' }, 'JSON' ), App.cap( 'manage' ) ? App.abtn( t( 'Email' ), function () {
							return SL.api( 'reports/' + r.id + '/email', { method: 'POST' } ).then( function ( x ) {
								SL.toast( x.sent ? t( 'Report sent.' ) : t( 'No recipients configured.' ), x.sent ? 'success' : 'error' );
							} );
						} ) : null );
					} },
				], rows, { empty: t( 'No reports yet' ) } ) );
			} );
		}
		load();
	};

	/* ================================================================ Alerts */
	/* Notifications: AI messages, warnings, results of changes, good news; follow-ups; e-mail. */
	var NK = {
		warning: [ '#dc2626', 'alert', t( 'Warnings' ), t( 'Warning' ) ],
		result: [ '#2563eb', 'chart', t( 'Results' ), t( 'Result' ) ],
		success: [ '#16a34a', 'check-circle', t( 'Good news' ), t( 'Good news' ) ],
		ai: [ '#7c3aed', 'sparkles', t( 'AI messages' ), t( 'Message from the AI' ) ],
		info: [ '#64748b', 'info', t( 'Info' ), t( 'Info' ) ],
	};

	function noticeCard( a, reload ) {
		var k = NK[ a.kind ] || NK.info;
		var data = a.data || {};
		var links = ( data.links || [] ).slice( 0, 4 );
		return h( 'article', { class: 'sl-mapcard sl-notice' + ( 'new' === a.status ? ' is-new' : '' ), style: '--c:' + k[ 0 ] },
			h( 'div', { class: 'sl-mapcard__head' },
				h( 'span', { class: 'sl-mapcard__ic', 'aria-hidden': 'true' }, SL.icon( k[ 1 ], 22 ) ),
				h( 'div', { class: 'sl-mapcard__titles' }, h( 'b', { class: 'sl-mapcard__title', dir: 'auto', text: a.title } ), h( 'span', { class: 'sl-muted sl-small', text: k[ 3 ] + ' · ' + SL.date( a.created_at ) + ( 'new' === a.status ? ' · ' + t( 'New' ) : '' ) } ) ),
				h( 'span', { class: 'sl-mapcard__status' }, h( 'b', { text: k[ 3 ] } ) )
			),
			a.message ? h( 'div', { class: 'sl-notice__msg', dir: 'auto' }, SL.markdown ? SL.markdown( a.message ) : a.message ) : null,
			h( 'div', { class: 'sl-mapcard__foot' },
				h( 'div', { class: 'sl-mapcard__flags' }, a.notified > 0 ? h( 'span', { class: 1 === +a.notified ? 'sl-mapcard__ok' : 'sl-mapcard__flag' }, SL.icon( 1 === +a.notified ? 'send' : 'alert', 13 ), h( 'span', { text: 1 === +a.notified ? t( 'Sent by e-mail' ) : t( 'E-mail failed' ) } ) ) : null ),
				h( 'div', { class: 'sl-mapcard__actions' },
					links.map( function ( l ) {
						return h( 'a', { class: 'sl-btn sl-btn--sm', href: l.url ? l.url : l.route, target: l.url ? '_blank' : null, rel: l.url ? 'noopener' : null, text: l.title } );
					} ),
					data.url ? App.ext( data.url, t( 'Open page' ) ) : null,
					App.btn( SL.icon( 'x', 16 ), function () {
						SL.api( 'alerts/' + a.id, { body: { status: 'dismissed' } } ).then( reload ).catch( SL.fail );
					}, 'ghost', { 'aria-label': t( 'Dismiss' ), title: t( 'Dismiss' ) } )
				)
			)
		);
	}

	function followUps( box ) {
		App.load( box, SL.api( 'follow-ups' ), function ( r ) {
			box.appendChild( h( 'p', { class: 'sl-muted', text: t( 'Every applied change is measured on day 7, 14, 28 and once more later: the same number of days after the change against before it, corrected by the whole site’s trend. Clear early results and every main result are sent to you (also by e-mail); the AI explains the result and puts the next steps on the SEO roadmap.' ) } ) );
			if ( r.data_until ) {
				box.appendChild( h( 'p', { class: 'sl-muted sl-small', text: t( 'Search Console data available until %s.', r.data_until ) } ) );
			}
			if ( ( r.learnings || [] ).length ) {
				box.appendChild( App.card( t( 'What worked on this site' ), App.table( [ { label: t( 'Change type' ), key: 'kind' }, { label: t( 'Measured' ), key: 'measured' }, { label: t( 'Positive' ), render: function ( l ) {
					return null === l.success_rate ? '—' : l.success_rate + '%';
				} }, { label: t( 'Clicks vs site trend' ), render: function ( l ) {
					return null === l.avg_lift ? '—' : ( l.avg_lift > 0 ? '+' : '' ) + l.avg_lift + '%';
				} }, { label: t( 'Position gain' ), render: function ( l ) {
					return null === l.avg_pos_gain ? '—' : l.avg_pos_gain;
				} } ], r.learnings ), { icon: 'flask', sub: t( 'The AI uses this record when it plans new changes.' ) } ) );
			}
			if ( ! r.items.length ) {
				box.appendChild( SL.empty( t( 'No follow-ups yet' ), t( 'Ask the AI chat “check this again in a month”, or apply a change.' ) ) );
				return;
			}
			var VN = { positive: [ t( 'Positive' ), '#16a34a' ], negative: [ t( 'Negative' ), '#dc2626' ], neutral: [ t( 'No clear change' ), '#2563eb' ], insufficient: [ t( 'Too little data' ), '#64748b' ] };
			var CONF = { high: t( 'high' ), medium: t( 'medium' ), low: t( 'low' ), insufficient: t( 'too little data' ) };
			var list = h( 'div', { class: 'sl-mapcards' } );
			r.items.forEach( function ( f ) {
				var done = 'waiting' !== f.status;
				var cps = f.checkpoints || [];
				var last = cps.length ? cps[ cps.length - 1 ] : null;
				var dv = last ? last.verdict : null;
				var col = dv ? VN[ dv.verdict ][ 1 ] : '#f59e0b';
				var timeline = h( 'div', { class: 'sl-chips' }, ( f.checkpoints_due || [] ).map( function ( day ) {
					var c = cps.filter( function ( x ) {
						return x.day === day;
					} )[ 0 ];
					return h( 'span', { class: 'sl-chip' + ( c ? ( 'positive' === c.verdict.verdict ? ' sl-chip--good' : ( 'negative' === c.verdict.verdict ? ' sl-chip--bad' : '' ) ) : '' ), title: c ? VN[ c.verdict.verdict ][ 0 ] : t( 'Not measured yet' ), text: t( 'Day %d', day ) + ( c ? ' · ' + VN[ c.verdict.verdict ][ 0 ] : '' ) } );
				} ) );
				var nums = dv ? h( 'ul', { class: 'sl-notice__lines' },
					h( 'li', { text: t( 'Clicks %1$s → %2$s (expected from the site trend %3$s, %4$s%%)', dv.clicks.before, dv.clicks.after, dv.clicks.expected, ( dv.clicks.lift > 0 ? '+' : '' ) + dv.clicks.lift ) } ),
					h( 'li', { text: t( 'Impressions %1$s → %2$s (%3$s%% vs site trend)', dv.impressions.before, dv.impressions.after, ( dv.impressions.lift > 0 ? '+' : '' ) + dv.impressions.lift ) } ),
					null !== dv.position.gain ? h( 'li', { text: t( 'Average position %1$s → %2$s', dv.position.before, dv.position.after ) } ) : null,
					h( 'li', { class: 'sl-muted', text: t( 'Whole site: clicks %1$s%%, impressions %2$s%% · confidence: %3$s', ( dv.site_trend.clicks > 0 ? '+' : '' ) + dv.site_trend.clicks, ( dv.site_trend.impressions > 0 ? '+' : '' ) + dv.site_trend.impressions, CONF[ dv.confidence ] ) } )
				) : null;
				var ai = f.ai ? h( 'div', { class: 'sl-alert sl-alert--info' },
					h( 'b', { text: t( 'AI analysis' ) } ),
					h( 'p', { dir: 'auto', text: f.ai.summary } ),
					( f.ai.next_actions || [] ).length ? h( 'ul', null, f.ai.next_actions.map( function ( a ) {
						return h( 'li', { dir: 'auto', text: a.title } );
					} ) ) : null,
					f.ai.revert ? h( 'p', { class: 'sl-bad', text: t( 'The AI recommends undoing this change (AI Changes → Undo).' ) } ) : null
				) : null;
				list.appendChild( h( 'article', { class: 'sl-mapcard', style: '--c:' + col },
					h( 'div', { class: 'sl-mapcard__head' },
						h( 'span', { class: 'sl-mapcard__ic', 'aria-hidden': 'true' }, SL.icon( cps.length ? 'chart' : 'calendar', 22 ) ),
						h( 'div', { class: 'sl-mapcard__titles' }, h( 'b', { class: 'sl-mapcard__title', dir: 'auto', text: f.title } ), h( 'span', { class: 'sl-muted sl-small', dir: 'auto', text: t( 'Changed on %s', f.change_date || SL.date( f.created_at ) ) + ( f.goal ? ' · ' + f.goal : '' ) } ) ),
						h( 'span', { class: 'sl-mapcard__status' }, h( 'b', { text: dv ? VN[ dv.verdict ][ 0 ] : t( 'Next check %s', f.check_at ) } ) )
					),
					timeline,
					h( 'div', { class: 'sl-chips' }, ( f.urls || [] ).map( function ( u ) {
						return h( 'span', { class: 'sl-chip', dir: 'ltr', text: decodeURI( u.replace( /^https?:\/\/[^/]+/, '' ) ) } );
					} ), ( f.queries || [] ).map( function ( q ) {
						return h( 'span', { class: 'sl-chip', dir: 'auto', text: '«' + q + '»' } );
					} ) ),
					nums,
					ai,
					h( 'div', { class: 'sl-mapcard__foot' }, h( 'span', { class: 'sl-muted sl-small', text: done ? t( 'Finished' ) : t( 'Created %s', SL.date( f.created_at ) ) } ), h( 'div', { class: 'sl-mapcard__actions' },
						! done ? App.abtn( t( 'Measure now' ), function () {
							return SL.api( 'follow-ups/' + f.id + '/check', { method: 'POST' } ).then( function () {
								followUps( SL.clear( box ) );
							} );
						} ) : null,
						App.btn( SL.icon( 'trash', 16 ), function () {
							SL.api( 'follow-ups/' + f.id, { method: 'DELETE' } ).then( function () {
								followUps( SL.clear( box ) );
							} ).catch( SL.fail );
						}, 'ghost' )
					) )
				) );
			} );
			box.appendChild( list );
		} );
	}

	function emailCard( e, reload ) {
		var on = h( 'input', { type: 'checkbox', checked: 'off' !== e.mode } );
		var to = h( 'textarea', { class: 'sl-input', dir: 'ltr', rows: 2, placeholder: 'you@example.com, team@example.com' } );
		to.value = ( e.to || [] ).join( ', ' );
		var mode = App.select( [ [ 'instant', t( 'Right away, one e-mail per notification' ) ], [ 'digest', t( 'Once a day, all new notifications together' ) ] ], 'digest' === e.mode ? 'digest' : 'instant', function () {} );
		var kinds = {};
		var last = e.last || null;
		return App.card( t( 'E-mail notifications' ), h( 'div', { class: 'sl-stack' },
			h( 'label', { class: 'sl-check' }, on, h( 'span', { text: t( 'Send notifications by e-mail' ) } ) ),
			h( 'label', { class: 'sl-field' }, h( 'span', { text: t( 'Recipients (comma separated)' ) } ), to ),
			h( 'label', { class: 'sl-field' }, h( 'span', { text: t( 'When' ) } ), mode ),
			h( 'div', { class: 'sl-field' }, h( 'span', { text: t( 'Which notifications' ) } ), h( 'div', { class: 'sl-chips' }, Object.keys( NK ).map( function ( k ) {
				kinds[ k ] = h( 'input', { type: 'checkbox', checked: ( e.kinds || [] ).indexOf( k ) >= 0 } );
				return h( 'label', { class: 'sl-chip' }, kinds[ k ], ' ' + NK[ k ][ 2 ] );
			} ) ) ),
			last ? h( 'div', { class: 'sl-alert ' + ( last.ok ? 'sl-alert--success' : 'sl-alert--error' ) }, h( 'b', { text: ( last.ok ? t( 'Last e-mail sent' ) : t( 'Last e-mail failed' ) ) + ' — ' + SL.date( last.at ) } ), last.error ? h( 'p', { text: last.error } ) : null ) : null,
			h( 'div', { class: 'sl-row' },
				App.abtn( t( 'Save' ), function () {
					return SL.api( 'alerts/email', { body: { enabled: on.checked ? 1 : 0, emails: to.value, mode: mode.value, kinds: Object.keys( kinds ).filter( function ( k ) {
						return kinds[ k ].checked;
					} ) } } ).then( function () {
						SL.toast( t( 'Saved' ), 'success' );
						reload();
					} );
				}, 'primary' ),
				App.abtn( SL.il( 'send', t( 'Send a test e-mail' ), 14 ), function () {
					return SL.api( 'alerts/test-email', { method: 'POST' } ).then( function ( r ) {
						SL.toast( r.ok ? t( 'Test e-mail sent to %s', r.to.join( ', ' ) ) : r.error, r.ok ? 'success' : 'error' );
						reload();
					} );
				} )
			),
			h( 'p', { class: 'sl-muted sl-small', text: t( 'E-mail goes through WordPress (wp_mail). If tests fail or land in spam, install an SMTP plugin such as WP Mail SMTP so mail is sent from a real mailbox.' ) } )
		), { icon: 'send' } );
	}

	App.pages.alerts = function ( v ) {
		var q = App.query ? App.query() : {};
		var state = { tab: q.tab || 'all' };
		var body = h( 'div', { class: 'sl-stack' } );
		v.appendChild( App.header( t( 'Notifications' ), t( 'Messages from SEOlity’s AI: warnings, results of your changes, good news, follow-ups and advice — also sent to your e-mail.' ), [ App.abtn( t( 'Mark all as read' ), function () {
			return SL.api( 'alerts/read-all', { method: 'POST' } ).then( function () {
				App.refreshBoot();
				load();
			} );
		} ) ] ) );
		v.appendChild( body );
		function load() {
			App.load( body, SL.api( 'alerts' ), function ( r ) {
				var tabs = [ { id: 'all', label: t( 'All' ) } ].concat( Object.keys( NK ).map( function ( k ) {
					return { id: k, label: NK[ k ][ 2 ] + ( r.unread_by_kind && r.unread_by_kind[ k ] ? ' (' + r.unread_by_kind[ k ] + ')' : '' ) };
				} ) ).concat( [ { id: 'follow', label: t( 'Follow-ups' ) }, { id: 'email', label: t( 'E-mail' ) } ] );
				var initial = 0;
				tabs.forEach( function ( x, i ) {
					if ( x.id === state.tab ) {
						initial = i;
					}
				} );
				body.appendChild( SL.tabs( tabs.map( function ( x ) {
					return { label: x.label, render: function () {
						state.tab = x.id;
						var b = h( 'div' );
						if ( 'follow' === x.id ) {
							followUps( b );
							return b;
						}
						if ( 'email' === x.id ) {
							b.appendChild( emailCard( r.email || {}, load ) );
							return b;
						}
						var items = 'all' === x.id ? r.items : r.items.filter( function ( a ) {
							return a.kind === x.id;
						} );
						if ( ! items.length ) {
							b.appendChild( SL.empty( t( 'Nothing here' ), t( 'SEOlity checks for important changes every hour and writes here.' ) ) );
							return b;
						}
						var list = h( 'div', { class: 'sl-mapcards' } );
						items.forEach( function ( a ) {
							list.appendChild( noticeCard( a, load ) );
						} );
						b.appendChild( list );
						// Seen = read (after the owner had a moment to notice what was new).
						setTimeout( function () {
							items.filter( function ( a ) {
								return 'new' === a.status;
							} ).forEach( function ( a ) {
								SL.api( 'alerts/' + a.id, { body: { status: 'read' } } ).catch( function () {} );
							} );
							App.refreshBoot();
						}, 2500 );
						return b;
					} };
				} ), null, initial ) );
			} );
		}
		load();
	};
} )( window );
